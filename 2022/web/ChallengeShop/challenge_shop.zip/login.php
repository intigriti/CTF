<?php
ini_set("display_errors", 0);
session_start();
if(isset($_POST['u']) && isset($_POST['p'])){
    $username = $_POST['u'];
    $password = $_POST['p'];
}
$error = '';
$conn = new PDO("mysql:host=127.0.0.1;dbname=auth", 'root', 'root');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if(isset($username) && !empty($username)){
    try {
        $stmt = $conn->prepare("SELECT username, `key` FROM users_erRP9T6C WHERE username=:u AND `key` = :p LIMIT 1");
        $stmt->execute(['u' => $username, 'p' => $password]);
        $rows = $stmt->fetchAll();
        if(!empty($rows)) {
            $_SESSION['username'] = $rows[0]['username'];
            $_SESSION['password'] = $rows[0]['key'];
        } else {
            $error = 'Wrong username and/or password';
        }
    } catch (Exception $e){
        $error = 'Wrong username and/or password';
    }
}
?>

<html>
    <head>
        <title>The Challenge Shop</title>
    </head>
    <body style="margin:0;padding:0">
        <div style="width: 100%; height: 40px; background: #1f2833">
            <div style="float: right; margin-right: 20px; margin-top: 10px;"><a href="/" style="color:#FFFFFF; font-weight: bold;">Home</a></div>
        </div>
        <div style="margin: auto; margin-top: 20px; text-align: center; width: 300px">
            <?php if(isset($_SESSION['username']) && $_SESSION['username'] == 'administrator'){?>
                <h1>Congratulations, did it!</h1>
                <h3>Hope you get the swag!</h3>
                <h4>And you liked the challenge!</h4>
            <?php
                session_destroy();
            } else {?>
            <form method="post" action="">
                <?php if($error != ''){?>
                    <div style="color:red"><h4><?php echo $error;?></h4></div>
                <?php } ?>
                <input type="text" style="height: 40px;" name="u" placeholder="Enter your username" value="">
                <div style="height: 10px"></div>
                <input type="password" style="height: 40px;" name="p" placeholder="Enter your password" value="">
                <div style="height: 10px"></div>
                <input type="submit" value="Login" style="height: 40px; padding: 10px; border: 0; background: #1f2833; color: #FFFFFF" />
            </form>
            <?php } ?>
        </div>
    </body>
</html>
