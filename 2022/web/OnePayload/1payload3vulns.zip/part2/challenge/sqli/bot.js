var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database(':memory:');

function initialize() {
    db.serialize(function() {
        db.run('CREATE TABLE users (username TEXT, password TEXT)');

        let stmt = db.prepare('INSERT INTO users VALUES (?, ?)');
        stmt.run('IntigritiAdministrator', 'SecretPassword');
        stmt.run('Guest', 'Guest');
        for (let i = 0; i < 10; i++) {
            stmt.run('TestAccount' + i, 'TestPassword' + i);
        }
        stmt.finalize();
    });
}

async function check(payload, callback) {
    console.log(`[SQLi] Checking -> ${payload}`);

    let didSQLiSucceed = false
    await db.get(`SELECT username FROM users WHERE username = "Guest" AND PASSWORD = "${payload}"`, function(err, row) {
        if (row !== undefined && row.username === 'IntigritiAdministrator') {
            console.log('[SQLi] Injection detected');
            didSQLiSucceed = true;
        }

        console.log(`[SQLi] Done checking -> ${payload}`);
        callback(didSQLiSucceed, row === undefined ? undefined : row.username);
    });
}

initialize();

module.exports = {
    check
};

console.log('[SQLi] Initiated');
