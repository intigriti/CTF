function drawWheel(params) {
    // Green: #74FC43; Red: #FC4349
    $('#doughnutChart').empty();
    $(function () {
        $("#doughnutChart").drawDoughnutChart(params);
    });
}

function parseHttpResponse(event) {
    if (event.target.readyState === 4 && event.target.status === 200) {
        let response = JSON.parse(event.target.responseText);
        let didXssWork = response['didXssWork'];
        let didSqliWork = response['didSqliWork'];
        let sqliUsername = response['SqliUsername']

        console.log(didXssWork ? '[XSS] Success' : '[XSS] Fail');
        console.log(didSqliWork ? '[SQLi] Success' : '[SQLi] Fail');

        drawWheel([
            {title: 'XSS', value: .5, color: didXssWork ? '#74FC43' : '#FC4349', text: `XSS: ${didXssWork ? '✅' : '❌'}`},
            {title: 'SQLi', value: .5, color: didSqliWork ? '#74FC43' : '#FC4349', text: `SQLi: ${didSqliWork ? '✅' : '❌'}`}
        ]);

        document.getElementById('sqliResultIframe').src = `/sqliresult.html?payload=${sqliUsername}`
    }
}

function doHttpGet(url, callback)
{
    const xmlHttp = new XMLHttpRequest();
    xmlHttp.open('GET', url);
    xmlHttp.onreadystatechange = callback;
    xmlHttp.send();
}

function payloadButtonClick() {
    let payload = encodeURIComponent(document.getElementById('payloadInput').value);
    console.log(`Clicked button. Payload -> ${payload}`)

    console.log('Changing iframe source')
    document.getElementById('vulnerableIframe').src = `/vulnerable?payload=${payload}`

    console.log('Sending payload');
    doHttpGet(`payload?payload=${payload}`, parseHttpResponse)
}

function onLoad() {
    console.log('Loaded webpage');

    document.getElementById('payloadButton').addEventListener('click', payloadButtonClick);

    $(function () {
        $("#doughnutChart").drawDoughnutChart([
            {title: 'XSS', value: .5, color: '#FC4349', text: 'XSS: ❌'},
            {title: 'SQLi', value: .5, color: '#FC4349', text: 'SQLi: ❌'}
        ]);
    });
}

window.addEventListener('load', onLoad);
