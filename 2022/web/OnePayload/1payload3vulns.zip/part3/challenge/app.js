const xss = require('./xss/bot');
const sqli = require('./sqli/bot');
const xxe = require('./xxe/bot');

const express = require('express');
const app = express();
const port = 3002;

app.use(express.static(__dirname + '/public'));
app.use('/vulnerable', express.static(__dirname + '/public/vulnerable.html'));

app.get('/payload', async (req, res) => {
    let payload = req.query.payload;
    console.log(`[1 PAYLOAD, 1 VULNERABILITY] Received payload -> ${payload}`);

    let results = {}

    await Promise.all([
        xss.browse(`http://localhost:${port}/vulnerable?payload=${encodeURIComponent(payload)}`, (result) => {
            if (result) console.log('[XSS] Successfully detected XSS');
            results['didXssWork'] = result;
        }),
        sqli.check(payload, (result, username) => {
            if (result) console.log('[SQLi] Successfully detected SQLi');
            results['didSqliWork'] = result;
            results['SqliUsername'] = username;
        }),
        xxe.check(payload, (result) => {
            if (result) console.log('[XXE] Successfully detected XXE');
            results['didXxeWork'] = result;
        })
    ]);

    res.send(results);
})

app.listen(port, () => {
    console.log(`[1 PAYLOAD, 1 VULNERABILITY] App listening at http://localhost:${port}`);
})
