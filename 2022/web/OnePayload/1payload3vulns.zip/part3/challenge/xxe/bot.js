const libxml = require('libxmljs');
const fs = require('fs');
const os = require("os");
const Path = require("path");

async function check(payload, callback) {
    console.log(`[XXE] Checking -> ${payload}`);

    let didXXESucceed = false;

    try {
        let secret = Math.random().toString(36);
        fs.writeFileSync(Path.join(os.tmpdir(), 'XxeValidationFile'), secret);
        let document = libxml.parseXml(payload, { noent: true, noet: true });
        console.log(document.toString())
        didXXESucceed = document.toString().includes(secret);

        if (didXXESucceed) {
            console.log('[XXE] Detected XXE')
        }
    } catch (err) {
        console.log(`[XXE] ${err}`);
    }

    callback(didXXESucceed);
}

module.exports = {
    check
};

console.log('[XXE] Initiated');
