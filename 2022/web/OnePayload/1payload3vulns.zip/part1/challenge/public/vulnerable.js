function findGetParameter(parameterName) {
    let result = null
    let tmp = [];
    location.search.substr(1).split("&").forEach(function (item) {
            tmp = item.split("=");
            if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
        });
    return result;
}

function onLoad() {
    console.log('Loaded webpage');

    document.getElementById('vulnerableParagraph').innerHTML = findGetParameter('payload');
}

window.addEventListener('load', onLoad);
