function drawWheel(params) {
    // Green: #74FC43; Red: #FC4349
    $('#doughnutChart').empty();
    $(function () {
        $("#doughnutChart").drawDoughnutChart(params);
    });
}

function parseHttpResponse(event) {
    if (event.target.readyState === 4 && event.target.status === 200) {
        let response = JSON.parse(event.target.responseText);
        let didXssWork = response['didXssWork'];

        console.log(didXssWork ? '[XSS] Success' : '[XSS] Fail');

        drawWheel([
            {title: 'XSS', value: 1, color: didXssWork ? '#74FC43' : '#FC4349', text: `XSS: ${didXssWork ? '✅' : '❌'}`}
        ]);
    }
}

function doHttpGet(url, callback)
{
    const xmlHttp = new XMLHttpRequest();
    xmlHttp.open('GET', url);
    xmlHttp.onreadystatechange = callback;
    xmlHttp.send();
}

function payloadButtonClick() {
    let payload = encodeURIComponent(document.getElementById('payloadInput').value);
    console.log(`Clicked button. Payload -> ${payload}`)

    console.log('Changing iframe source')
    document.getElementById('vulnerableIframe').src = `/vulnerable?payload=${payload}`

    console.log('Sending payload');
    doHttpGet(`payload?payload=${payload}`, parseHttpResponse)
}

function onLoad() {
    console.log('Loaded webpage');

    document.getElementById('payloadButton').addEventListener('click', payloadButtonClick);

    $(function () {
        $("#doughnutChart").drawDoughnutChart([
            {title: 'XSS', value: 1, color: '#FC4349', text: 'XSS: ❌'}
        ]);
    });
}

window.addEventListener('load', onLoad);
