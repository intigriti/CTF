module.exports = {
  content: ["./html/templates/*.html.twig"],
  theme: {
    extend: {},
  },
  plugins: [
    require('@tailwindcss/typography'),
    // ...
  ],
}
