<?php

$timestamp = $_GET['t'] ?? null;

if ($timestamp === null) {
    throw new \RuntimeException('Missing value in query "timestamp" parameter.');
}

$key = 'LJH2NvCyxTEjmR47Q@HCrRAZBGMgo*pH';
$nonce = hash_hmac('md5', $timestamp, $key);

echo $nonce;
