<?php

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Session\Storage\NativeSessionStorage;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

require_once __DIR__ . '/../vendor/autoload.php';

$loader = new FilesystemLoader(__DIR__ . '/templates');
$twig = new Environment($loader, [
    'cache' => __DIR__ . '/../cache',
]);

$session = null;
$session_factory = fn () => $session ?? $session = new Session(new NativeSessionStorage());

$request = Request::createFromGlobals();
$request->setSessionFactory($session_factory);

$response = new Response();
$todos_response = function (Request $request, Response $response) use ($twig) {
    $todos = $request->getSession()->get('todos', []);
    $ids = array_keys($todos);

    $renderer = fn ($todo, $id) => $twig->render(
        sprintf('todo-%sdone.html.twig', empty($todo['done']) ? 'not-' : ''),
        compact('todo', 'id')
    );
    $content = array_map($renderer, $todos, $ids);

    $response->setContent(implode(PHP_EOL, $content));
};

switch (true) {
    case ($request->isMethod('POST') && $request->request->get('action') === 'add'):
        $text = $request->request->get('text');

        if (!is_string($text)) {
            $error = sprintf(
                'Text must be of type "string". Got "%s".',
                gettype($text)
            );

            $response->setStatusCode($response::HTTP_BAD_REQUEST);
            $response->setContent($error);

            break;
        }
        elseif (mb_strlen($text) < 1) {
            $response->setStatusCode($response::HTTP_BAD_REQUEST);
            $response->setContent('Text cannot be empty.');

            break;
        }

        $todos = $request->getSession()->get('todos', []);
        $last_id = $request->getSession()->get('last_id', 0);

        $todos[++$last_id] = [
            'text' => $request->request->get('text'),
            'done' => false,
        ];

        $request->getSession()->set('todos', $todos);
        $request->getSession()->set('last_id', $last_id);

        $todos_response($request, $response);
        break;

    case ($request->isMethod('POST') && $request->request->get('action') === 'mark'):
        $id = $request->request->getInt('id');
        $done = $request->request->getBoolean('done');

        if (empty($id)) {
            $response->setStatusCode($response::HTTP_BAD_REQUEST);
            $response->setContent('Missing todo ID.');

            break;
        }

        $todos = $request->getSession()->get('todos', []);

        if (!isset($todos[$id])) {
            $response->setStatusCode($response::HTTP_BAD_REQUEST);
            $response->setContent('Unknown todo ID.');

            break;
        }

        $todos[$id]['done'] = $done;

        $request->getSession()->set('todos', $todos);

        $todos_response($request, $response);
        break;

    case ($request->isMethod('POST') && $request->request->get('action') === 'remove'):
        $id = $request->request->getInt('id');

        if (empty($id)) {
            $response->setStatusCode($response::HTTP_BAD_REQUEST);
            $response->setContent('Missing todo ID.');

            break;
        }

        $todos = $request->getSession()->get('todos', []);

        if (!isset($todos[$id])) {
            $response->setStatusCode($response::HTTP_BAD_REQUEST);
            $response->setContent('Unknown todo ID.');

            break;
        }

        unset($todos[$id]);

        $request->getSession()->set('todos', $todos);

        $todos_response($request, $response);
        break;

    case ($request->isMethod('GET') && $request->query->get('action') === 'get-todos'):
        $todos_response($request, $response);
        break;

    default:
        $timestamp = $request->server->get('REQUEST_TIME', $_SERVER['REQUEST_TIME'] ?? time());
        $content = $twig->render('index.html.twig', compact('timestamp'));

        $response->setContent($content);

        break;
}

$response->send();
