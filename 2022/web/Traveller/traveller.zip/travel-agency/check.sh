#!/bin/bash

single="42"
couple="12"
family="60"
company="4"

if [[ $1 == "Single" ]]
then
  echo "Spots left: $single.";
elif [[ $1 == "Couple" ]]
then
  echo "Spots left: $couple.";
elif [[ $1 == "Family" ]]
then
  echo "Spots left: $family.";
elif [[ $1 == "Company" ]]
then
  echo "Spots left: $company.";
fi
