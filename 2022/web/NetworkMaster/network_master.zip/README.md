# NameNetwork - 1337UP LIVE CTF 2022

This repo contains the code for the NameNetwork CTF I made for [Intigriti](https://www.intigriti.com/)'s 1337UP LIVE CTF 2022

# Setup

You can run this CTF locally by simply cloning this repo and following these steps (you need to have docker and docker compose installed):

-   Run the following command `docker-compose up -d`
-   Navigate to `http://localhost:80`

#### Optional:

You can change the port the app should run on by modifiying line 7 in `./docker-compose.yml`
