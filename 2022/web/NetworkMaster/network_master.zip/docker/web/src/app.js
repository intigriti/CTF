require('dotenv').config();
const path = require('path')
const express = require('express');
const cookieParser = require('cookie-parser');
const { engine } = require('express-handlebars');

const app = express();

const waf = (req,res,next)=>{
    if(/[<>'"]/.test(decodeURIComponent(req.url))){
        res.status(400).send('Request contains illegal chars')
        return
    }
    for (const [key, val] of Object.entries(req.body)) {
        if(/[<>'"]/.test(key) || /[<>'"]/.test(val)){
            res.status(400).send('Request contains illegal chars')
            return
        }
    }
    next()
}

app.engine('handlebars', engine())
app.set('view engine', 'handlebars')
app.set('views', path.join(__dirname, './views'))

app.use(express.static(path.join(__dirname, './static')))
app.use(express.json())
app.use(cookieParser())
app.use(waf)


//Routes
app.use('/', require('./routes/index'))
app.use('/api', require('./routes/api'))

app.all('*', (re,res)=>{
    res.status(404).send('<h2>Whoops, we could not find the requested resource</h2>')
})

const PORT = process.env.PORT || 3000
app.listen(PORT, ()=>{
    console.log(`Listening on port ${PORT}`)
})