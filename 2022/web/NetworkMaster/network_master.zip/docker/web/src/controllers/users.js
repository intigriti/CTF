const db = require('../db/db')
const { validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');

const customValidationResult = validationResult.withDefaults({
    formatter: error => {
      return {
        msg: error.msg,
      };
    },
  });

const addUser = async (req, res, next)=>{
    const errors = customValidationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    try{
        const {firstName, lastName, email} = req.body
        const id = uuidv4()
        const sql = `INSERT INTO users(id, first_name, last_name, email) VALUES(?,?,?,?)`
        await db.execute(sql, [id,firstName,lastName,email])
        res.send({"id":id,"firstName":firstName,"lastName":lastName,"email":email})
    }catch(err){
        next(err)
    }
}

const findUsersWithSameName = async (req, res, next)=>{
    const errors = customValidationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    
    try{
        const {userId} = req.cookies
        let sql = `SELECT * FROM users WHERE id = ? LIMIT 1`
        const [[user],] = await db.execute(sql, [userId])
        if(user){
            sql = `SELECT * FROM users WHERE (first_name = '${user.first_name}' OR last_name = '${user.last_name}') AND admitted AND id != '${userId}'`
            const [users,] = await db.execute(sql)
            res.status(200).send(users)
        }else{
            res.status(400).send('No user exists with the specified userId')
        }
    }catch(err){
        next(err)
    }
}

const getUsers = async (req, res, next)=>{
    try{
        const sql = `SELECT * FROM users WHERE admitted`
        const [users, _] = await db.execute(sql)
        res.send(users)
    }catch(err){
        next(err)
    }
}

module.exports = {
    addUser,
    findUsersWithSameName,
    getUsers,
}