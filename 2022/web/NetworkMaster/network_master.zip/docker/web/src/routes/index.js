const express = require('express');
const db = require('../db/db')
const { param, validationResult } = require('express-validator');

const router = express.Router()

router.get('/', (req,res)=>{
    res.render('home')
})

router.get('/apply', (req,res)=>{
    res.render('apply')
})

router.get('/user/:id', param('id').isUUID().withMessage('userId is invalid'), async (req, res)=>{
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    const userId = req.params.id
    let sql = `SELECT * FROM users WHERE id = ? AND admitted LIMIT 1`
    const [[user],] = await db.execute(sql, [userId])
    if(user){
        res.render('user', {user})
    }else{
        return res.status(400).json({ error: "User has not been admitted" });
    }
})
module.exports = router