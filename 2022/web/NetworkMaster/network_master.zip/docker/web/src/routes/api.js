const express = require('express');
const router = express.Router()

const { body, cookie } = require('express-validator');

const {addUser, findUsersWithSameName, getUsers} = require('./../controllers/users');

router.post(
    '/user',
    body('firstName').not().isEmpty().withMessage('First name cannot be empty'),
    body('lastName').not().isEmpty().withMessage('Last name cannot be empty'),
    body('email').isEmail().withMessage('Email is invalid'),
    body('password').isLength({min: 8}).withMessage('Password must be at least 8 characters long'),
    addUser
    )

router.get('/users', getUsers)

router.get('/user/findUsersWithSameName', cookie('userId').not().isEmpty().withMessage('userId is not set').bail().isUUID().withMessage('userId is invalid'), findUsersWithSameName)


module.exports = router