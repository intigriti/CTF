async function findUsersWithSameName(){
    let data = await fetch('/api/user/findUsersWithSameName').then(res=>res.json())
    console.log(data)
}