module.exports = {
  content: ["./src/views/*.handlebars","./src/views/layouts/*.handlebars"],
  theme: {
    extend: {
      fontFamily:{
        logo: ['Bungee', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
