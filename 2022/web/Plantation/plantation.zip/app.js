const xss = require('./xss/bot');

const express = require('express');
const app = express();
const port = 3000;

app.use(express.static(__dirname + '/public'));

app.get('/payload', async (req, res) => {
    let payload = req.url.substr(8);
    console.log(`[1 PAYLOAD, 1 VULNERABILITY] Received payload -> ${payload}`);

    let results = {}

    await Promise.all([
        xss.browse(`http://localhost:${port}/${payload}`, (result) => {
            if (result) console.log('[XSS] Successfully detected XSS');
            results['didXssWork'] = result;
            if (result) results['flag'] = '1337UP{Th3_Pl4nts_are_angry_now!!!}';
        })
    ]);

    res.send(results);
})

app.listen(port, () => {
    console.log(`[1 PAYLOAD, 1 VULNERABILITY] App listening at http://localhost:${port}`);
})
