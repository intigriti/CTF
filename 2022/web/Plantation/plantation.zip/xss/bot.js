const puppeteer = require('puppeteer');

async function browse(url, callback) {
    console.log(`[XSS] Browsing -> ${url}`);
    const browser = await (await puppeteer.launch({headless: true, args: ['--no-sandbox', '--disable-gpu']})).createIncognitoBrowserContext();

    const page = await browser.newPage();
    await page.setUserAgent('BOT');

    // If we get an alert popup
    let didXssSucceed = false
    page.on('dialog', async (dialog) => {
        console.log('[XSS] Dialog detected');
        didXssSucceed = true;
        await dialog.dismiss();
    });

    try {
        await page.goto(url, {
            waitUntil: 'networkidle0',  // Wait until popup might have appeared.
            timeout: 1 * 1000,
        });
    } catch (err) {
        console.log(`[XSS] ${err}`);
    }

    await page.close();
    await browser.close();

    console.log(`[XSS] Done visiting -> ${url}`);
    callback(didXssSucceed);
}

module.exports = {
    browse
};

console.log('[XSS] Initiated');
