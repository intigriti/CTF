import web
import sys
from io import StringIO
import string

urls = (
  '/', 'index',
  '/old', 'old',
)
render = web.template.render('templates/')
app = web.application(urls, globals())

class index:
    def GET(self):
        source = f'\x3cpre\x3e\x3ccode\x3e{open(__file__).read()}\x3c/code\x3e\x3c/pre\x3e'
        return render.index(source, '')

class old:
    def GET(self):
        eval_output = ''
        stdout = sys.stdout
        sys.stdout = reportSIO = StringIO()
        blacklist = string.printable
        try:
            get_input = web.input()
            inject = get_input['inject'] if 'inject' in get_input else None       
            if (inject):
                try:
                    x = eval(inject)
                    if (x):
                        eval_output = str(eval_output) + x
                except Exception as error:
                    print(error)
            for x in inject:
                if any(x in inject for x in blacklist):
                    return "caught you again 1337"
            reportStr = reportSIO.getvalue()
            sys.stdout = stdout
            output = str(reportStr) + str(eval_output)
            return render.index(f'\x3cpre\x3e\x3ccode\x3e{open(__file__).read()}\x3c/code\x3e\x3c/pre\x3e', output)
        except Exception as error: 
            print(error)
            return error

    
if __name__ == "__main__":
    app.run()
