<?php
/*
	<flag>
		You made it 🤗
		-> 1337UP{PHP_SCARES_ME_IT_HAUNTS_ME_WHEN_I_SLEEP_ALL_I_CAN_SEE_IS_PHP_PLEASE_SOMEONE_HELP_ME} <-
	<flag>
*/
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
	extract($_POST);

	if (isset($_POST['password']) && md5($_POST['password']) == 'put hash here!'){
		$loggedin = true;
	}

	if (md5($_SERVER['REMOTE_ADDR']) != '92d3fd4057d07f38474331ab231e1f0d'){
		header('Location: ' . $_SERVER['REQUEST_URI']);
	}

	if (isset($loggedin) && $loggedin){
		echo 'One step closer 😎<br>';

		if (isset($_GET['action']) && md5($_GET['action']) == $_GET['action']){
			echo 'Really? 😅<br>';

			$db = new SQLite3('database.db');
			$sql_where = Array('1=0');

			foreach ($_POST as $key => $data) {
				$sql_where[] = $db->escapeString($key) . "='" . $db->escapeString($data) . "'";
			}

			$result = $db->querySingle('SELECT login FROM users WHERE ' . implode(' AND ', $sql_where));

			if ($result == 'admin'){
				echo 'Last step 🤣<br>';

				readfile(file_get_contents('php://input'));
			}
		}
	}
}
?>

<html lang="en">
	<head>
		<title>PHorrifyingP</title>
        <style>
            body {
                background-color: #000;
            }
            h1 {
                font-size: 8vw;
                font-family: 'Nosifer', cursive;
                padding: 2rem;
                color: #900d0d;
                text-shadow: 0 0 5px #fff, 0 0 10px #fff, 0 0 15px #d92027, 0 0 20px #d92027, 0 0 25px #d92027, 0 0 30px #d92027, 0 0 55px #d92027;
                animation: glow 1s ease-in-out infinite alternate;
                text-align: center;
            }
            @keyframes glow {
                from {
                    text-shadow: 0 0 5px #fff, 0 0 10px #fff, 0 0 15px #d92027, 0 0 20px #d92027, 0 0 25px #d92027, 0 0 30px #d92027, 0 0 55px #d92027;
                }
                to {
                    text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 40px #d92027, 0 0 40px #d92027, 0 0 50px #d92027, 0 0 70px #d92027, 0 0 90px #d92027;
                }
            }
            p {
                max-width: 50%;
                margin: auto;
            }
        </style>
	</head>
	<body>
        <link href="https://fonts.googleapis.com/css2?family=Nosifer&display=swap" rel="stylesheet">
        <h1>PHorrifyingP</h1>
        <p>
            <?php
                $source = highlight_file(__FILE__, true);
                $source = explode('&lt;flag&gt;', $source);
                $source[1] = ' ➡➡➡ ⛳🏁 ⬅⬅⬅ ';
                $source = implode('&lt;flag&gt;', $source);
                echo $source;
            ?>
        </p>
	</body>
</html>
