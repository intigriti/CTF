from flask import Flask, request,flash, session,url_for, make_response,render_template,redirect
from os import listdir
from os.path import isfile, join
from PIL import Image
from flask_cors import CORS

from flask import send_from_directory
from stegano import lsb
import random
import os

app = Flask(__name__)
app.config['STATIC_IMAGES'] = 'static/images/'
app.config['MAX_CONTENT_PATH'] = 256



app.secret_key = "thisismysupersecretkeysaslkdjaslkdnlkasndlkansd"

artpassw = "Mich3l@ngel0$ist1n3!511"

if __name__ == "__main__":
    app.run(debug=True)

FLAG="SuperSecretFlagDrLeekRocks"

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def get_rnd_img(directory):
    onlyfiles = [f for f in listdir(directory) if isfile(join(directory, f))]
    image = onlyfiles[random.randint(0,len(onlyfiles) -1)]
    return directory + "/" +image

def get_rnd_img_matching(directory,firstimg):
    prefix = "_".join(firstimg.split("_")[:-1])
    matching_files = [f for f in listdir(directory) if isfile(join(directory, f)) and f.startswith(prefix)]

    if not matching_files: 
        return None
    image = matching_files[random.randint(0, len(matching_files) - 1)]
    return join(directory, image)

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')

@app.route('/', methods =['GET'])
def home():
    res = make_response("heyo")
    return redirect(url_for('comic'))

@app.route('/heartbeat', methods =['GET'])
def heartbeat():
    return make_response( 'Nothing interesting here .... unless https://www.youtube.com/shorts/hu-Oqb4IfjE ', 200)


@app.route('/comic',methods=['GET'])
def comic():
    print("new comic requested !")

    filepath1 = get_rnd_img('static/images/first_p')
    imagename = filepath1.split('/')[-1]
    img1 = Image.open(filepath1)     
    img2 = Image.open(get_rnd_img_matching('static/images/second_p',imagename))
    img3 = Image.open(get_rnd_img('static/images/third_p'))

    img1 = img1.resize((400,400))
    img2 = img2.resize((400,400))
    img3 = img3.resize((400,400))

    new_image = Image.new('RGB',(3*img1.size[0],img1.size[1]),(250,250,250))
    new_image.paste(img1,(0,0))
    new_image.paste(img2,(img1.size[0],0))
    new_image.paste(img3,(img2.size[0] + img1.size[0],0))

    new_image.save("static/images/merged_image.png","PNG")    
    
    secret = lsb.hide("static/images/merged_image.png","password:" + artpassw)
    secret.save("static/images/merged_image.png")
    return render_template('display.html')

@app.route('/artist',methods=['GET'])
def artist():
    return render_template('artist.html')

@app.route('/super_secret_art_dashboard',methods=['GET'])
def super_secret_art_dashboard():
    return("Good job here is your flag FLG " + FLAG,200)


@app.route('/artist_login',methods=['POST','GET'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')

    artadmin = "Picasso"

    otp = request.form.get('otp')
    if username is None:
        flash('Empty login.')
        return redirect(url_for('artist'))
    
    if username != artadmin:
        flash('Incorrect Username.')
        return redirect(url_for('artist'))
    
    if password != artpassw:
        print(password)
        flash('Incorrect Password.')
        return redirect(url_for('artist'))
    

    token = random.randint(000,999);
    token = (f"{token:03d}")

    if otp != token:
        flash('Incorrect login.')
        return redirect(url_for('artist'))

    session['username'] = artadmin 
    return redirect(url_for('super_secret_art_dashboard'))
