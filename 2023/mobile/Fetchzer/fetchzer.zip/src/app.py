from flask import Flask, jsonify, request, render_template, send_file
import sqlite3
import binascii
import base64

app = Flask(__name__)


def check_enc_token(enc_token):
    conn = sqlite3.connect("./quotes.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE enc_access_token = ?", (enc_token,))
    result = cursor.fetchone()

    return result


def xor_with_key(data, key_bytes):
    xor_result = bytearray()
    for i, byte in enumerate(data):
        xor_result.append(byte ^ key_bytes[i % len(key_bytes)])

    return base64.urlsafe_b64encode(binascii.hexlify(xor_result)).decode("utf-8")


def get_quotes(username):
    conn = sqlite3.connect("./quotes.db")
    cursor = conn.cursor()

    cursor.execute("SELECT * from quotes where owned_by = ?", (username,))
    results = cursor.fetchall()

    quotes = [result for result in results]
    return quotes


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/download")
def download_apk():
    apk_filename = "fetchzer-0.1-arm64.apk"
    return send_file(f"downloads/{apk_filename}", as_attachment=True)


@app.route("/api/createToken", methods=["POST"])
def create_token():
    username = request.form.get("username")
    access_token = request.form.get("access_token")

    if username == "admin":
        return jsonify({"error": "Can't make tokens for the admin user!"})

    if username and access_token:
        secret_key = b"LwKSukajw"
        encrypted_token = xor_with_key(access_token.encode("utf-8"), secret_key)

        conn = sqlite3.connect("./quotes.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (username, access_token, enc_access_token) VALUES (?, ?, ?)",
            (username, access_token, encrypted_token),
        )
        conn.commit()
        conn.close()

        return jsonify({"encrypted_token": encrypted_token})

    else:
        return jsonify({"error": "Error occured whilte creating the token!"})


@app.route("/api/addQuote", methods=["POST"])
def add_quote():
    enc_access_token = request.form.get("enc_access_token")
    token_info = check_enc_token(enc_access_token)

    if token_info is None:
        return jsonify({"error": "Invalid access token"})

    quote = request.form.get("quote")
    quote_by = request.form.get("author")
    owner = token_info[1]

    conn = sqlite3.connect("./quotes.db")
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO quotes (quote, quote_by, owned_by) VALUES (?, ?, ?)",
        (quote, quote_by, owner),
    )
    conn.commit()
    conn.close()

    return jsonify({"message": "Quote added successfully"})


@app.route("/api/getQuotes", methods=["GET"])
def getQuotes():
    enc_access_token = request.args.get("xor_token")
    token_info = check_enc_token(enc_access_token)

    if token_info is None:
        return jsonify({"error": "Invalid access token"})

    else:
        quotes = get_quotes(token_info[1])

        return jsonify({"quotes": quotes})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
