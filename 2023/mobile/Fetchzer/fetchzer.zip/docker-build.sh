#!/bin/bash
/usr/bin/docker rmi --force fetchzer-web
/usr/bin/docker build -t  fetchzer-web .
