#!/bin/bash
/usr/bin/docker run -p 80:80  fetchzer-web