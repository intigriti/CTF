<?php
$db = new mysqli('db', 'user', 'password','db');

function sqlesc($s){
	global $db;
	return $db->real_escape_string((string)$s);
}

function sqlquery($s){
	global $db;
	if ($r = $db->query($s)) {
		return $r->fetch_all(MYSQLI_ASSOC);
	}
	return array();
}
