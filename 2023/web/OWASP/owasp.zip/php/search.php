<?php
require_once('db.php');
$flag = file_get_contents('/flag.txt');
@include('header.php');

//build sql query
$sql = 'select * from owasp';
$sql_where = '';
foreach ($_REQUEST as $field => $value){
  if ($sql_where) $sql_where = " AND $sql_where";
  $sql_where = "position(%s in $field) $sql_where";
  try {
    $sql_where = @vsprintf($sql_where, Array("'". sqlesc($value) . "'"));
  } catch (ValueError | TypeError $e) {
    $sql_where = '';
  }
  if (preg_match('/[^a-z0-9\.\-_]/i', $field)) die ('Hacking attempt!');
}
$sql .= ($sql_where)?" where $sql_where":'';

foreach(sqlquery($sql) as $row){
  @include('row.php');
  $config = json_decode($row['config'], true);
}

if (isset($config['flag']) && $config['flag']){
  $url = $config['url'];
  // no printer manufacturer domains
  if (preg_match('/canon|epson|brother|hp|minolta|sharp|dell|oki|samsung|xerox|lexmark/i', $url)) die('Looks like a printer!');
//  $url = 'https://www.youtube.com/watch?v=2U3Faa3DejQ';
  if (filter_var($url, FILTER_VALIDATE_URL)) {
    $http_resp = file_get_contents($url);
    var_dump($http_resp);
    if ($flag === $http_resp){
      die('Yes! You got the right flag!');
    }
    die('Wrong flag');
  }
  else {
    die('URL does not start with HTTP or HTTPS protocol!');
  }
}

@include('footer.php');
