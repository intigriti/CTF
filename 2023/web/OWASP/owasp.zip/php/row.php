  <li>
    <h2><?=$row['id'];?></h2>
    <h3><?=$row['title'];?></h3>
    <p><?=$row['description'];?></p>
    <p>
      <a href="https://blog.intigriti.com/2021/09/10/owasp-top-10/#<?=$row['id']?>" target="blog" class="readMore">Read more</a>
    </p>
  </li>
