
<html>
<head>
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'">
    <title>OWASP Top10 2021</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div id="app">
<form action="search.php" method="GET">
<input type="text" name="title" />
<input type="submit" value="🔍">
</form>
<ul class="tilesWrap">
