### SET NAMES utf8;
SET time_zone = '+00:00';
### SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

###CREATE DATABASE `db` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;
###USE `db`;

DROP TABLE IF EXISTS `flag`;
CREATE TABLE `flag` (
  `flag` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `flag` (`flag`) VALUES
('https://www.youtube.com/watch?v=dQw4w9WgXcQ');

DROP TABLE IF EXISTS `owasp`;
CREATE TABLE `owasp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `config` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `owasp` (`id`, `title`, `description`, `config`) VALUES
(1,	'A01:2021-Broken Access Control',	'moves up from the fifth position to the category with the most serious web application security risk; the contributed data indicates that on average, 3.81% of applications tested had one or more Common Weakness Enumerations (CWEs) with more than 318k occurrences of CWEs in this risk category. The 34 CWEs mapped to Broken Access Control had more occurrences in applications than any other category.',	'{}'),
(2,	'A02:2021-Cryptographic Failures',	'shifts up one position to #2, previously known as A3:2017-Sensitive Data Exposure, which was broad symptom rather than a root cause. The renewed name focuses on failures related to cryptography as it has been implicitly before. This category often leads to sensitive data exposure or system compromise.',	'{\"__proto__\":{\"flag\":\"https://www.youtube.com/watch?v=Ct6BUPvE2sM\"}}'),
(3,	'A03:2021-Injection',	'slides down to the third position. 94% of the applications were tested for some form of injection with a max incidence rate of 19%, an average incidence rate of 3.37%, and the 33 CWEs mapped into this category have the second most occurrences in applications with 274k occurrences. Cross-site Scripting is now part of this category in this edition.',	'{}'),
(4,	'A04:2021-Insecure Design',	'is a new category for 2021, with a focus on risks related to design flaws. If we genuinely want to \\\"move left\\\" as an industry, we need more threat modeling, secure design patterns and principles, and reference architectures. An insecure design cannot be fixed by a perfect implementation as by definition, needed security controls were never created to defend against specific attacks.',	'{\"flag\":false}'),
(5,	'A05:2021-Security Misconfiguration',	'moves up from #6 in the previous edition; 90% of applications were tested for some form of misconfiguration, with an average incidence rate of 4.5%, and over 208k occurrences of CWEs mapped to this risk category. With more shifts into highly configurable software, it\'s not surprising to see this category move up. The former category for A4:2017-XML External Entities (XXE) is now part of this risk category.',	'{}'),
(6,	'A06:2021-Vulnerable\",\"description',	'and Outdated Components was previously titled Using Components with Known Vulnerabilities and is #2 in the Top 10 community survey, but also had enough data to make the Top 10 via data analysis. This category moves up from #9 in 2017 and is a known issue that we struggle to test and assess risk. It is the only category not to have any Common Vulnerability and Exposures (CVEs) mapped to the included CWEs, so a default exploit and impact weights of 5.0 are factored into their scores.',	'false'),
(7,	'A07:2021-Identification and Authentication Failures',	'was previously Broken Authentication and is sliding down from the second position, and now includes CWEs that are more related to identification failures. This category is still an integral part of the Top 10, but the increased availability of standardized frameworks seems to be helping.',	'[]'),
(8,	'A08:2021-Software and Data Integrity Failures',	'is a new category for 2021, focusing on making assumptions related to software updates, critical data, and CI/CD pipelines without verifying integrity. One of the highest weighted impacts from Common Vulnerability and Exposures/Common Vulnerability Scoring System (CVE/CVSS) data mapped to the 10 CWEs in this category. A8:2017-Insecure Deserialization is now a part of this larger category.',	'1337'),
(9,	'A09:2021-Security Logging and Monitoring Failures',	'was previously A10:2017-Insufficient Logging & Monitoring and is added from the Top 10 community survey (#3), moving up from #10 previously. This category is expanded to include more types of failures, is challenging to test for, and isn\'t well represented in the CVE/CVSS data. However, failures in this category can directly impact visibility, incident alerting, and forensics.',	'\"1337UP\"'),
(10,	'A10:2021-Server-Side Request Forgery',	'is added from the Top 10 community survey (#1). The data shows a relatively low incidence rate with above average testing coverage, along with above-average ratings for Exploit and Impact potential. This category represents the scenario where the security community members are telling us this is important, even though it\'s not illustrated in the data at this time.',	'null');
