import React from 'react';

function NoPage() {
    return (
        <h1>NoPage</h1>
    );
}

export default NoPage;