function writeData(st, data){
    console.log(st, data);
}