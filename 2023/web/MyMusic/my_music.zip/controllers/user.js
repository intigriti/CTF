const {
    createUser,
    getUser,
    setUserData,
    userExists,
} = require('../services/user')
const { validationResult } = require('express-validator')

const addUser = (req, res, next) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        return res.status(400).send(errors.array())
    }

    const { username, firstName, lastName } = req.body
    const userData = {
        username,
        firstName,
        lastName,
    }
    try {
        const loginHash = createUser(userData)
        res.status(204)
        res.cookie('login_hash', loginHash, { secure: false, httpOnly: true })
        res.send()
    } catch (e) {
        console.log(e)
        res.status(500)
        res.send('Error creating user!')
    }
}

const getUserData = (req, res, next) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        return res.status(400).send(errors.array())
    }
    const { loginHash } = req.body
    try {
        const userData = getUser(loginHash)
        res.send(JSON.parse(userData))
    } catch (e) {
        console.log(e)
        res.status(500)
        res.send('Error fetching user!')
    }
}

const updateUserData = (req, res, next) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        return res.status(400).send(errors.array())
    }

    const { firstName, lastName, spotifyTrackCode } = req.body
    const userData = {
        username: req.userData.username,
        firstName,
        lastName,
        spotifyTrackCode,
    }
    try {
        setUserData(req.loginHash, userData)
        res.send()
    } catch (e) {
        console.log(e)
        res.status(500).send('Error updating user!')
    }
}

const authenticateAsUser = (req, res) => {
    const errors = validationResult(req)
    if (!errors.isEmpty()) {
        return res.status(400).send(errors.array())
    }
    const { loginHash } = req.body
    if (userExists(loginHash)) {
        res.cookie('login_hash', loginHash, { httpOnly: true })
        res.send()
    } else {
        res.status(404).send('User not found')
    }
}

module.exports = { addUser, getUserData, updateUserData, authenticateAsUser }
