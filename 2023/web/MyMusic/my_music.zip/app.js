const express = require('express')
const { engine } = require('express-handlebars')
const cookieParser = require('cookie-parser')
const { auth } = require('./middleware/auth')

const app = express()

app.engine('handlebars', engine())
app.set('view engine', 'handlebars')
app.set('views', './views')

app.use(express.json())
app.use(cookieParser())
app.use(auth)

app.use('/static', express.static('static'))

app.use('/', require('./routes/index'))
app.use('/api', require('./routes/api'))

app.listen(3000, () => {
    console.log('Listening on port 3000...')
})
