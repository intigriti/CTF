# MyMusic - 1337UP LIVE CTF 2023

This repo contains the code for the MyMusic challenge made for the 1337UP LIVE CTF 2023.

## Challenge text

Checkout my new platform for sharing the tunes of your life!

## Build docker image

```bash
docker build -t my-music .
```

## Run docker image

Replace `<PORT>` with the host port

```bash
docker run -dp <PORT>:3000 -e FLAG='FLAG{some_cool_ctf_flag}' my-music
```
