const puppeteer = require('puppeteer')
const fs = require('fs')
const path = require('path')
const { v4: uuidv4 } = require('uuid')
const Handlebars = require('handlebars')

const generatePDF = async (userData, userOptions) => {
    let templateData = fs.readFileSync(
        path.join(__dirname, '../views/print_profile.handlebars'),
        {
            encoding: 'utf8',
        }
    )
    const template = Handlebars.compile(templateData)
    const html = template({ userData: userData })

    const filePath = path.join(__dirname, `../tmp/${uuidv4()}.html`)
    fs.writeFileSync(filePath, html)

    const browser = await puppeteer.launch({
        executablePath: '/usr/bin/google-chrome',
        args: ['--no-sandbox'],
    })
    const page = await browser.newPage()
    await page.goto(`file://${filePath}`, { waitUntil: 'networkidle0' })
    await page.emulateMediaType('screen')

    let options = {
        format: 'A5',
    }

    if (userOptions) {
        options = { ...options, ...userOptions }
    }

    const pdf = await page.pdf(options)
    fs.unlinkSync(filePath)
    return pdf
}

module.exports = { generatePDF }
