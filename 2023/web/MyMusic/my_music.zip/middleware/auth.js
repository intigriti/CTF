const { userExists, getUser } = require('../services/user')

const auth = (req, res, next) => {
    let loginHash = req.cookies['login_hash']
    if (loginHash && userExists(loginHash)) {
        try {
            let userData = JSON.parse(getUser(loginHash))
            req.userData = userData
            req.loginHash = loginHash
        } catch (e) {
            console.log(e)
        }
    }
    next()
}

const requireAuth = (req, res, next) => {
    if (!req.userData) {
        return res.redirect('/login')
    }
    next()
}

module.exports = { auth, requireAuth }
