const { getUser, userExists } = require('../services/user')

const isAdmin = (req, res, next) => {
    let loginHash = req.cookies['login_hash']
    let userData
    if (loginHash && userExists(loginHash)) {
        userData = getUser(loginHash)
    } else {
        return res.redirect('/login')
    }

    try {
        userData = JSON.parse(userData)
        if (userData.isAdmin !== true) {
            res.status(403)
            res.send('Only admins can view this page')
            return
        }
    } catch (e) {
        console.log(e)
    }
    next()
}

module.exports = { isAdmin }
