const express = require('express')
const { body, cookie } = require('express-validator')
const {
    addUser,
    getUserData,
    updateUserData,
    authenticateAsUser,
} = require('../controllers/user')

const router = express.Router()

router.post(
    '/register',
    body('username').not().isEmpty().withMessage('Username cannot be empty'),
    body('firstName').not().isEmpty().withMessage('First name cannot be empty'),
    body('lastName').not().isEmpty().withMessage('Last name cannot be empty'),
    addUser
)

router.post(
    '/login',
    body('loginHash').not().isEmpty().withMessage('Login hash cannot be empty'),
    authenticateAsUser
)

router
    .get('/user', getUserData)
    .put(
        '/user',
        body('firstName')
            .not()
            .isEmpty()
            .withMessage('First name cannot be empty'),
        body('lastName')
            .not()
            .isEmpty()
            .withMessage('Last name cannot be empty'),
        body('spotifyTrackCode')
            .not()
            .isEmpty()
            .withMessage('Spotify track code cannot be empty'),
        cookie('login_hash').not().isEmpty().withMessage('Login hash required'),
        updateUserData
    )

module.exports = router
