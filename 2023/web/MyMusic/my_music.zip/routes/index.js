const express = require('express')
const { requireAuth } = require('../middleware/auth')
const { isAdmin } = require('../middleware/check_admin')
const { getRandomRecommendation } = require('../utils/recommendedSongs')
const { generatePDF } = require('../utils/generateProfileCard')

const router = express.Router()

router.get('/', (req, res) => {
    const spotifyTrackCode = getRandomRecommendation()
    res.render('home', { userData: req.userData, spotifyTrackCode })
})

router.get('/register', (req, res) => {
    res.render('register', { userData: req.userData })
})

router.get('/login', (req, res) => {
    if (req.loginHash) {
        res.redirect('/profile')
    }
    res.render('login', { userData: req.userData })
})

router.get('/logout', (req, res) => {
    res.clearCookie('login_hash')
    res.redirect('/')
})

router.get('/profile', requireAuth, (req, res) => {
    res.render('profile', { userData: req.userData, loginHash: req.loginHash })
})

router.post('/profile/generate-profile-card', requireAuth, async (req, res) => {
    const pdf = await generatePDF(req.userData, req.body.userOptions)
    res.contentType('application/pdf')
    res.send(pdf)
})

router.get('/admin', isAdmin, (req, res) => {
    res.render('admin', {
        flag:
            process.env.FLAG ||
            'INTIGRITI{0verr1d1ng_4nd_n0_r3turn_w4s_n3ed3d_for_th15_fl4g_to_b3_e4rn3d}',
    })
})

module.exports = router
