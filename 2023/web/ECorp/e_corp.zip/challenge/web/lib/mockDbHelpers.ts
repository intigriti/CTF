import { Client, StaffUser } from "@/types/client";

import db from "./mockDb.json";

type Criteria<T> = {
    [K in keyof T]?: T[K];
};

export const mockDb = {
    staffUsers: db.staffUsers as StaffUser[],
    clients: db.clients as Client[],
    getStaffUser(criteria: Criteria<StaffUser>): StaffUser[] {
        return this.staffUsers.filter((user) =>
            Object.keys(criteria).every(
                (key) => user[key as keyof StaffUser] === criteria[key as keyof StaffUser]
            )
        );
    },
    getClient(criteria: Criteria<Client>): Client[] {
        return this.clients.filter((client) =>
            Object.keys(criteria).every(
                (key) => client[key as keyof Client] === criteria[key as keyof Client]
            )
        );
    },
    getStaffUserById(id: string): StaffUser | undefined {
        return this.staffUsers.find((user) => user.id === id);
    },
    getClientById(id: string): Client | undefined {
        return this.clients.find((client) => client.id === id);
    },
};
