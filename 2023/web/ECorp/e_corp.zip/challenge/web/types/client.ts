export type StaffUser = {
    id: string;
    level: number;
    username: string;
    securityQuestion: string;
    password: string;
};

export type Client = {
    id: string;
    name: string;
    surname: string;
    age: number;
    photo: string;
    gender: string;
    mood: string;
    bank: number;
    friends: number;
    healthy: boolean;
    status: string;
};
