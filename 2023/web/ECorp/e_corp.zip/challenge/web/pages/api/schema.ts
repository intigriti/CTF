import builder from "@/pages/api/builder";

import "./mutations";

import { mockDb } from "@/lib/mockDbHelpers";

export const StaffUserType = builder.objectType("StaffUser", {
    fields: (t) => ({
        id: t.exposeString("id", {}),
        level: t.exposeInt("level", {}),
        username: t.exposeString("username", {}),
        securityQuestion: t.exposeString("securityQuestion", {}),
    }),
});

export const ClientType = builder.objectType("Client", {
    // Provide a definition for the fields of the Client type
    fields: (t) => ({
        id: t.exposeString("id", {}),
        name: t.exposeString("name", {}),
        surname: t.exposeString("surname", {}),
        age: t.exposeInt("age", {}),
        photo: t.exposeString("photo", {}),
        gender: t.exposeString("gender", {}),
        mood: t.exposeString("mood", {}),
        bank: t.exposeFloat("bank", {}),
        friends: t.exposeInt("friends", {}),
        healthy: t.exposeBoolean("healthy", {}),
        status: t.exposeString("status", {}),
    }),
});

builder.queryFields((t) => ({
    getClientsList: t.field({
        type: [ClientType],
        resolve: async () => {
            try {
                return mockDb.clients;
            } catch (error) {
                throw new Error("Failed to retrieve clients list");
            }
        },
    }),
    getClient: t.field({
        type: ClientType,
        nullable: true,
        args: {
            id: t.arg.string({ required: true }),
        },
        resolve: async (_, args) => {
            const client = mockDb.getClientById(args.id);
            if (!client) {
                throw new Error(`Client with ID ${args.id} not found`);
            }
            return client;
        },
    }),
    getStaffList: t.field({
        type: [StaffUserType],
        resolve: async () => {
            try {
                return mockDb.staffUsers;
            } catch (error) {
                throw new Error("Failed to retrieve staff users list");
            }
        },
    }),
    getStaffUser: t.field({
        type: StaffUserType,
        nullable: true,
        args: {
            id: t.arg.string({ required: true }),
        },
        resolve: async (_, args) => {
            const staffUser = mockDb.getStaffUserById(args.id);
            if (!staffUser) {
                throw new Error(`StaffUser with ID ${args.id} not found`);
            }
            return staffUser;
        },
    }),
}));

export const schema = builder.toSchema();
