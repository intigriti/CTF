import { setCookie } from "@/common/utils/setCookie";
import builder from "@/pages/api/builder";
import { SignJWT } from "jose";
import { mockDb } from "@/lib/mockDbHelpers";

builder.mutationFields((t) => ({
  deleteStaffUser: t.field({
    type: "StaffUser",
    args: {
      id: t.arg.string({ required: true }),
    },
    resolve: async (_, args, context, info) => {
      throw new Error("Unauthorized. Required access level: 0. This incident will be reported.");
    },
  }),
  _devSetLevel: t.field({
    type: "StaffUser",
    args: {
      i: t.arg.string({ required: true }),
      l: t.arg.int({ required: true }),
    },
    resolve: async (_, args, context, info) => {
      const { i, l } = args;
      const { res } = context;

      const user = await mockDb.getStaffUserById(i);

      if (!user) {
        throw new Error("Invalid id");
      }

      const jwtToken = await new SignJWT({ userId: user.id, level: l })
                        .setProtectedHeader({ alg: 'HS256' })
                        .setIssuedAt()
                        .setExpirationTime('1d')
                        .sign(new TextEncoder().encode(process.env.JWT_SECRET));

      setCookie(res, "t", jwtToken, {
        httpOnly: true,
        path: "/",
        maxAge: 60 * 60 * 1000, // 1 hour
      });

      return {
        ...user,
        level: l
      }
    },
  }),

c2Login: t.field({
    type: "StaffUser",
    args: {
      i: t.arg.string({ required: true }),
      p: t.arg.string({ required: true }),
    },
    resolve: async (_, args, context, info) => {
      const { i, p } = args;
      const { res } = context;

      const user = await mockDb.getStaffUserById(i);

      if (!user) {
        throw new Error("Invalid id");
      }

      const jwtToken = await new SignJWT({ userId: user.id, level: user.level })
                        .setProtectedHeader({ alg: 'HS256' })
                        .setIssuedAt()
                        .setExpirationTime('1h')
                        .sign(new TextEncoder().encode(process.env.JWT_SECRET));

      setCookie(res, "t", jwtToken, {
        httpOnly: true,
        path: "/",
        maxAge: 60 * 60 * 1000, // 1 hour
      });

      return user;
    },
  }),
}));
