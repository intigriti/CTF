import { Client, StaffUser } from "@/types/client";
import { faker } from "@faker-js/faker";
import bcrypt from "bcrypt";
import fs from "fs";
import path from "path";

const secretQuestions = [
  "What is your favorite food?",
  "What brings you joy?",
  "What is your favorite animal?",
];

const hashedPwd = bcrypt.hashSync("cat", 10);

// Generate mock StaffUsers
const generateStaffUsers = () => {
  let staffUsers = [];
  staffUsers.push({
    id: "32FM19790306873AEB",
    level: 1,
    username: faker.internet.userName("Emma", "Turner"),
    securityQuestion: secretQuestions[2],
    password: hashedPwd,
  });
  
  for (let i = 0; i < 10; i++) {
    staffUsers.push({
      id: faker.datatype.uuid(),
      level: faker.datatype.number({ min: 0, max: 1 }),
      username: faker.internet.userName(),
      securityQuestion: faker.helpers.arrayElement(secretQuestions),
      password: bcrypt.hashSync(faker.internet.password(), 10),
    });
  }
  return staffUsers;
};

// Generate mock Clients
const generateClients = () => {
  let clients = [];
  for (let i = 0; i < 50; i++) {
    clients.push({
      id: faker.datatype.uuid(),
      name: faker.name.firstName(),
      surname: faker.name.lastName(),
      age: faker.datatype.number({ min: 18, max: 90 }),
      photo: faker.image.avatar(),
      gender: faker.name.gender(),
      mood: faker.helpers.arrayElement([
        "happy", "sad", "neutral", "angry", "surprised", "disgusted", "fearful", "calm", "confused", "aroused"
      ]),
      bank: faker.datatype.number({ max: 1000000000 }),
      friends: faker.datatype.number({ max: 150 }),
      healthy: faker.datatype.boolean(),
      status: faker.helpers.arrayElement(["dead", "alive", "sick"]),
    });
  }
  return clients;
};

const mockDb = {
  staffUsers: generateStaffUsers(),
  clients: generateClients(),
};

const mockDbContent = JSON.stringify(mockDb, null, 2)

// Write the mockDb module to the file system
fs.writeFileSync(path.join(__dirname, '../lib/mockDb.json'), mockDbContent, 'utf-8');

console.log('Mock database file created successfully.');
