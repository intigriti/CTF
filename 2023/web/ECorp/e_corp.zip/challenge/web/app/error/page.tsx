export default function ErrorPage() {
    return <div>Unrecognized device.</div>;
}
