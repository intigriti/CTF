
export const GSAP_DESKTOP_MEDIA = "(min-width: 1001px)"
export const GSAP_MOBILE_MEDIA = "(max-width: 1000px)"
