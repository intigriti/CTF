# SmartyPants
Since you're so smart then you should have no problem with this one