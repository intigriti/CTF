import os
import socket
import threading
import pyfiglet
from termcolor import colored

FLAG = os.getenv('FLAG', 'INTIGRITI{fake_flag}')


def xor_encrypt(plaintext, key):
    key = (key * (len(plaintext) // len(key) + 1))[:len(plaintext)]
    encrypted = bytearray()

    for i in range(len(plaintext)):
        encrypted.append(plaintext[i] ^ key[i])

    return encrypted


def handle_client(client_socket):
    try:
        # Set a timeout for client interactions (e.g., 30 seconds)
        client_socket.settimeout(30)

        banner = pyfiglet.figlet_format("IrrORversible Encryption")
        client_socket.send(colored(banner, 'green').encode('utf-8'))

        client_socket.send(colored(
            "Welcome to the military grade cryptosystem!\n", 'cyan').encode('utf-8'))
        client_socket.send(colored(
            "Please enter the text you would like to encrypt:\n", 'yellow').encode('utf-8'))

        plaintext = client_socket.recv(260)

        # Handle case where input is empty or exceeds limit
        if len(plaintext) <= 1:
            client_socket.send(
                colored("Error: No input provided!\n", 'red').encode('utf-8'))
        elif len(plaintext) > 256:
            client_socket.send(
                colored("Error: Input exceeds 256 bytes limit!\n", 'red').encode('utf-8'))
        else:
            ciphertext = xor_encrypt(plaintext, FLAG.encode('utf-8'))

            client_socket.send(
                colored("\nYour encrypted ciphertext (hex format):\n", 'cyan').encode('utf-8'))
            client_socket.send(ciphertext.hex().encode('utf-8'))
            client_socket.send(
                colored("\nThank you for playing!\n", 'green').encode('utf-8'))

    except socket.timeout:
        client_socket.send(
            colored("Error: Connection timed out.\n", 'red').encode('utf-8'))
    except socket.error:
        client_socket.send(
            colored("Error: Server encountered a problem!\n", 'red').encode('utf-8'))
    except Exception:
        client_socket.send(
            colored("An error occurred!\n", 'red').encode('utf-8'))
    finally:
        # Ensure the socket is always closed
        client_socket.close()


def start_server():
    try:
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.bind(("0.0.0.0", 1330))

        # Increase the backlog size to allow more pending connections
        server.listen(100)

        while True:
            try:
                client_socket, addr = server.accept()
                print(f"[*] Accepted connection from {addr}")

                # Create a daemon thread for the client handler to avoid resource leaks
                client_handler = threading.Thread(
                    target=handle_client, args=(client_socket,))
                # Daemon thread will automatically exit when the main thread exits
                client_handler.daemon = True
                client_handler.start()

            except socket.error:
                print("Error accepting connection")
            except Exception as e:
                print(f"Server error: {e}")

    except Exception as e:
        print(f"Critical server error: {e}")
    finally:
        # Ensure the server socket is closed if anything goes wrong
        server.close()
        print("[*] Server shutdown")


if __name__ == "__main__":
    start_server()
