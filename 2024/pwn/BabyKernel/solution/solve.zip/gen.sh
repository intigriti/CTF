#!/bin/bash

# Check if the initramfs directory exists
if [ ! -d "initramfs" ]; then
    echo "initramfs directory not found. Creating and extracting..."
    
    mkdir initramfs
    pushd . && pushd initramfs
    
    # Copy and extract the initramfs.cpio.gz file
    cp ../initramfs.cpio.gz .
    gzip -dc initramfs.cpio.gz | cpio -idm &>/dev/null && rm initramfs.cpio.gz
    
    popd
else
    echo "initramfs directory exists. Skipping creation and extraction."
fi

# Compile the exploit
gcc exploit.c -o ./initramfs/home/ctf/exploit -no-pie -static
# Alternative gcc command (if needed)
# gcc exploit.c -o ./initramfs/home/ctf/exploit -no-pie -static -masm=intel

# Repack the initramfs
cd initramfs && find . -print0 | cpio --null -ov --format=newc | gzip -9 > ../initramfs.cpio.gz 
cd ..

# Boot the system
./boot.sh
