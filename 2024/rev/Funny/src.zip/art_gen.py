from ascii_mapping import ascii_art
from string import ascii_uppercase, digits

__all__ = ["make_art"]

def make_art(msg) -> str:
    assert all(c in ascii_uppercase + digits + "_" for c in msg)
    assert ascii_art[msg[0]][0][0] != ' ', "Top left of first char in msg must not be a space to avoid ambiguity"
    rows = [[] for _ in range(7)]

    for char in msg:
        for i, chunk in enumerate(ascii_art[char]):
            rows[i].append(chunk)
    
    return "\n".join("  ".join(row) for row in rows)
        