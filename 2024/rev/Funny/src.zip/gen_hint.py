from os import urandom
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

__all__ = ["make_hint"]

def make_hint(hint: bytes | bytearray) -> str:
    assert isinstance(hint, (bytes, bytearray))
    key = urandom(32)
    cipher = AES.new(key, AES.MODE_CBC)
    ct = cipher.encrypt(pad(hint, AES.block_size))
    iv = cipher.iv

    return f"i_wonder_what_this_decrypts_to = {ct!r}\nunpad(AES.new({key!r}, AES.MODE_CBC, {iv!r}).decrypt(i_wonder_what_this_decrypts_to), AES.block_size)\n"
