import sys, os.path, py_compile, re, secrets, string
sys.dont_write_bytecode = True

from gen_hint import *
from art_gen import *

exp_cwd = os.path.dirname(__file__)
if os.getcwd() != exp_cwd:
    os.chdir(exp_cwd)

FLAG_FORMAT = "INTIGRITI"

boilerplate = """
try:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad, unpad
except ImportError:
    print("run `pip install pycryptodome` to be able to play this challenge")
    exit()

""".lstrip()

get_key_and_iv = """
a=b=c=d=e=f=g=h=i=j=k=l=m=n=o=p=q=r=s=t=u=v=w=x=y=z=0
key = input("Key > ").encode()
iv  = input("IV  > ").encode()
if len(key) == 32 and len(iv) == 16:
    decrypted = unpad(AES.new(key, AES.MODE_CBC, iv).decrypt({ct!r}), AES.block_size)
    if b{FLAG_FORMAT!r} in decrypted:
        print("gg")
        print(decrypted.decode())
    del decrypted

del key, iv

""".lstrip()

hint = """
If you've uncovered this message, you're probably on the right track.

The goal for this challenge is to figure out the correct key and IV to decrypt the flag. You must have noticed all the names being pushed and popped and wondered what they're for...
I promise it's not too scary. The key to decrypt this flag is written in ASCII art using these names, so you must reconstruct the source for everything under this
message decryption down to the exact spacing. The IV is the characters at positions
{positions}
in that exact order joined together where (0, 0) is the *TOP LEFT* of where the ASCII art begins.

For example, consider the following *FAKE* ASCII art where the IV positions are [(0, 0), (5, 1), (2, 6), (10, 6)]

axxxx   x       xxxxxxxxx
x    b  x           x
x    x  x           x
xxxxx   x           x
x    x  x           x
x    x  x           x
xxcxx   xxdxxx      x

In this example, the key would be "BLT" and the IV would be "abcd" since the character at (0, 0) is 'a', (5, 1) is 'b', (2, 6) is 'c', and (10, 6) is 'd'.

To clarify further, all semicolons are placed "normally" meaning that they're placed directly after a statement with no spacing (ex: a;b;   c;  d;), the final IV will only contain characters a-z, and I highly recommend
using a text editor that uses an equal width for all characters to avoid misalignment.

Good luck!
""".strip()

def encrypt_flag(flag: str, key: bytes, iv: bytes | None = None) -> tuple[bytes, bytes]:
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ct_bytes = cipher.encrypt(pad(flag.encode(), AES.block_size))
    return cipher.iv, ct_bytes

key = "P05IT1ON4L_INF0RM4TION_1S_GR34T_"
art = make_art(msg=key)

repl = lambda _: string.ascii_lowercase[secrets.randbelow(26)] + ';'
art = re.sub(r"[a-z]", repl, art).replace(" ", "  ")

split_art = art.split("\n")
iv_positions = []
while len(iv_positions) != 16:
    x, y = secrets.randbelow(len(split_art[0])), secrets.randbelow(len(split_art))
    if split_art[y][x] not in "; " and (x, y) not in iv_positions:
        iv_positions.append((x, y))

iv = "".join(map(lambda pos: split_art[pos[1]][pos[0]], iv_positions)).encode()

# INTIGRITI{y0u_7ruly_4r3_7h3_pyc_p4r51n6_m4573r}
FLAG = f"{FLAG_FORMAT}{{y0u_7ruly_4r3_7h3_pyc_p4r51n6_m4573r}}"
_, ct = encrypt_flag(FLAG, key.encode(), iv)

chal_src = ""
chal_src += boilerplate
chal_src += get_key_and_iv.format(iv=iv, ct=ct, FLAG_FORMAT=FLAG_FORMAT)
chal_src += make_hint(hint=hint.format(positions=iv_positions).encode())
chal_src += "\n\n"
chal_src += art

with open("chal.py", "w") as file:
    file.write(chal_src)

output = py_compile.compile("chal.py", "challenge.pyc")
print(f"compiled bytecode to {output}")
