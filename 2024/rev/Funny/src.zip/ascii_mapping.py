ascii_art = {
    'A': [
        "  xxx  ",
        " x   x ",
        "x     x",
        "xxxxxxx",
        "x     x",
        "x     x",
        "x     x"
    ],
    'B': [
        "xxxxxx ",
        "x     x",
        "x     x",
        "xxxxxx ",
        "x     x",
        "x     x",
        "xxxxxx "
    ],
    'C': [
        " xxxxx ",
        "x     x",
        "x      ",
        "x      ",
        "x      ",
        "x     x",
        " xxxxx "
    ],
    'D': [
        "xxxxx  ",
        "x    x ",
        "x     x",
        "x     x",
        "x     x",
        "x    x ",
        "xxxxx  "
    ],
    'E': [
        "xxxxxxx",
        "x      ",
        "x      ",
        "xxxxx  ",
        "x      ",
        "x      ",
        "xxxxxxx"
    ],
    'F': [
        "xxxxxxx",
        "x      ",
        "x      ",
        "xxxxx  ",
        "x      ",
        "x      ",
        "x      "
    ],
    'G': [
        " xxxxx ",
        "x     x",
        "x      ",
        "x  xxxx",
        "x     x",
        "x     x",
        " xxxxx "
    ],
    'H': [
        "x     x",
        "x     x",
        "x     x",
        "xxxxxxx",
        "x     x",
        "x     x",
        "x     x"
    ],
    'I': [
        "xxxxxxx",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   ",
        "xxxxxxx"
    ],
    'J': [
        "xxxxxxx",
        "    x  ",
        "    x  ",
        "    x  ",
        "x   x  ",
        "x   x  ",
        " xxx   "
    ],
    'K': [
        "x    x ",
        "x   x  ",
        "x  x   ",
        "xxx    ",
        "x  x   ",
        "x   x  ",
        "x    x "
    ],
    'L': [
        "x      ",
        "x      ",
        "x      ",
        "x      ",
        "x      ",
        "x      ",
        "xxxxxxx"
    ],
    'M': [
        "x     x",
        "xx   xx",
        "x x x x",
        "x  x  x",
        "x     x",
        "x     x",
        "x     x"
    ],
    'N': [
        "x     x",
        "xx    x",
        "x x   x",
        "x  x  x",
        "x   x x",
        "x    xx",
        "x     x"
    ],
    'O': [
        " xxxxx ",
        "x     x",
        "x     x",
        "x     x",
        "x     x",
        "x     x",
        " xxxxx "
    ],
    'P': [
        "xxxxxx ",
        "x     x",
        "x     x",
        "xxxxxx ",
        "x      ",
        "x      ",
        "x      "
    ],
    'Q': [
        " xxxxx ",
        "x     x",
        "x     x",
        "x     x",
        "x   x x",
        "x    x ",
        " xxxx x"
    ],
    'R': [
        "xxxxxx ",
        "x     x",
        "x     x",
        "xxxxxx ",
        "x   x  ",
        "x    x ",
        "x     x"
    ],
    'S': [
        " xxxxx ",
        "x     x",
        "x      ",
        " xxxxx ",
        "      x",
        "x     x",
        " xxxxx "
    ],
    'T': [
        "xxxxxxx",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   "
    ],
    'U': [
        "x     x",
        "x     x",
        "x     x",
        "x     x",
        "x     x",
        "x     x",
        " xxxxx "
    ],
    'V': [
        "x     x",
        "x     x",
        "x     x",
        "x     x",
        " x   x ",
        "  x x  ",
        "   x   "
    ],
    'W': [
        "x     x",
        "x     x",
        "x     x",
        "x  x  x",
        "x x x x",
        "xx   xx",
        "x     x"
    ],
    'X': [
        "x     x",
        " x   x ",
        "  x x  ",
        "   x   ",
        "  x x  ",
        " x   x ",
        "x     x"
    ],
    'Y': [
        "x     x",
        " x   x ",
        "  x x  ",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   "
    ],
    'Z': [
        "xxxxxxx",
        "     x ",
        "    x  ",
        "   x   ",
        "  x    ",
        " x     ",
        "xxxxxxx"
    ],
    '0': [
        " xxxxx ",
        "x     x",
        "x    xx",
        "x  x  x",
        "xx    x",
        "x     x",
        " xxxxx "
    ],
    '1': [
        "  xx   ",
        " x x   ",
        "   x   ",
        "   x   ",
        "   x   ",
        "   x   ",
        "xxxxxxx"
    ],
    '2': [
        " xxxxx ",
        "x     x",
        "      x",
        " xxxxx ",
        "x      ",
        "x      ",
        "xxxxxxx"
    ],
    '3': [
        " xxxxx ",
        "x     x",
        "      x",
        "  xxxx ",
        "      x",
        "x     x",
        " xxxxx "
    ],
    '4': [
        "x    x ",
        "x    x ",
        "x    x ",
        "xxxxxxx",
        "     x ",
        "     x ",
        "     x "
    ],
    '5': [
        "xxxxxxx",
        "x      ",
        "x      ",
        "xxxxxx ",
        "      x",
        "x     x",
        " xxxxx "
    ],
    '6': [
        " xxxxx ",
        "x     x",
        "x      ",
        "xxxxxx ",
        "x     x",
        "x     x",
        " xxxxx "
    ],
    '7': [
        "xxxxxxx",
        "     x ",
        "    x  ",
        "   x   ",
        "  x    ",
        " x     ",
        "x      "
    ],
    '8': [
        " xxxxx ",
        "x     x",
        "x     x",
        " xxxxx ",
        "x     x",
        "x     x",
        " xxxxx "
    ],
    '9': [
        " xxxxx ",
        "x     x",
        "x     x",
        " xxxxxx",
        "      x",
        "x     x",
        " xxxxx "
    ],
    '_': [
        "       ",
        "       ",
        "       ",
        "       ",
        "       ",
        "       ",
        "xxxxxxx"
    ]
}