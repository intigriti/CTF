#include <iostream>
#include <sstream>
#include <string>
#include <mysql_driver.h>
#include <mysql_connection.h>
#include <cppconn/statement.h>
#include <cppconn/resultset.h>
#include <iomanip>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <cstring>
#include <cstdlib>
#include <thread>
#include <memory>

#define BACKLOG 10

const unsigned char key1[16] = {0x07, 0x7d, 0x22, 0x7a, 0x15, 0x15, 0x79, 0x3a, 0x27, 0x71, 0x05, 0x46, 0x04, 0x51, 0x54, 0x02};
const unsigned char key2[16] = {0x49, 0x4e, 0x54, 0x49, 0x47, 0x52, 0x49, 0x54, 0x49, 0x31, 0x33, 0x33, 0x37, 0x75, 0x70, 0x23};

std::string generatePassword() {
    std::string password;
    for (int i = 0; i < 16; i++) {
        password += (key1[i] ^ key2[i]);
    }
    return password;
}

bool checkPassword(const std::string &input) {
    std::string correctPassword = generatePassword();
    return input == correctPassword;
}

void handleProductSearch(int client_sock, sql::Connection *con) {
    const char *clearScreen = "\033[2J\033[H";
    send(client_sock, clearScreen, strlen(clearScreen), 0);

    std::string productAsciiArt = R"(
    **      Product Search        **
 ▄▄▄·▄▄▄        ·▄▄▄▄  ▄• ▄▌ ▄▄· ▄▄▄▄▄.▄▄ · 
▐█ ▄█▀▄ █·▪     ██▪ ██ █▪██▌▐█ ▌▪•██  ▐█ ▀. 
 ██▀·▐▀▀▄  ▄█▀▄ ▐█· ▐█▌█▌▐█▌██ ▄▄ ▐█.▪▄▀▀▀█▄
▐█▪·•▐█•█▌▐█▌.▐▌██. ██ ▐█▄█▌▐███▌ ▐█▌·▐█▄▪▐█
.▀   .▀  ▀ ▀█▄▀▪▀▀▀▀▀•  ▀▀▀ ·▀▀▀  ▀▀▀  ▀▀▀▀ 

)";
    send(client_sock, productAsciiArt.c_str(), productAsciiArt.length(), 0);

    std::string prompt = "Enter product name:\n";
    send(client_sock, prompt.c_str(), prompt.length(), 0);

    char buffer[1024] = {0};
    recv(client_sock, buffer, sizeof(buffer), 0);
    std::string productName(buffer);
    productName.erase(productName.find_last_not_of(" \n\r\t") + 1); // Trim whitespace

    try {
        std::string query = "SELECT name, price FROM products WHERE name = '" + productName + "'";

        sql::Statement *stmt = con->createStatement();
        sql::ResultSet *res = stmt->executeQuery(query);

        std::ostringstream output;
        output << "Product Search Results:\n";
        while (res->next()) {
            std::string name = res->getString("name");
            double price = res->getDouble("price");

            output << "Name: " << name << ", Price: $" << std::fixed << std::setprecision(2) << price << "\n";
        }
        output << "Press Enter to return to the main menu...";
        send(client_sock, output.str().c_str(), output.str().length(), 0);

        char buffer2[1024] = {0};
        recv(client_sock, buffer2, sizeof(buffer2), 0);

        delete res;
        delete stmt;
    } catch (sql::SQLException &e) {
        std::string error = "SQLException: " + std::string(e.what()) + "\n";
        send(client_sock, error.c_str(), error.length(), 0);
    }
}

void handleOrderSearch(int client_sock, sql::Connection *con) {
    const char *clearScreen = "\033[2J\033[H";
    send(client_sock, clearScreen, strlen(clearScreen), 0);

    std::string orderAsciiArt = R"(
    **      Order Search        **
      ▄▄▄  ·▄▄▄▄  ▄▄▄ .▄▄▄  .▄▄ · 
▪     ▀▄ █·██▪ ██ ▀▄.▀·▀▄ █·▐█ ▀. 
 ▄█▀▄ ▐▀▀▄ ▐█· ▐█▌▐▀▀▪▄▐▀▀▄ ▄▀▀▀█▄
▐█▌.▐▌▐█•█▌██. ██ ▐█▄▄▌▐█•█▌▐█▄▪▐█
 ▀█▄▀▪.▀  ▀▀▀▀▀▀•  ▀▀▀ .▀  ▀ ▀▀▀▀ 

)";
    send(client_sock, orderAsciiArt.c_str(), orderAsciiArt.length(), 0);

    std::string prompt = "Enter order number:\n";
    send(client_sock, prompt.c_str(), prompt.length(), 0);

    char buffer[1024] = {0};
    recv(client_sock, buffer, sizeof(buffer), 0);
    std::string orderNumber(buffer);
    orderNumber.erase(orderNumber.find_last_not_of(" \n\r\t") + 1); // Trim whitespace

    try {
        std::string query = "SELECT order_number, total FROM orders WHERE order_number = " + orderNumber;

        sql::Statement *stmt = con->createStatement();
        sql::ResultSet *res = stmt->executeQuery(query);

        std::ostringstream output;
        output << "Order Search Results:\n";
        while (res->next()) {
            std::string orderNum = std::to_string(res->getInt("order_number"));
            double total = res->getDouble("total");

            output << "Order Number: " << orderNum << ", Total: $" << std::fixed << std::setprecision(2) << total << "\n";
        }
        output << "Press Enter to return to the main menu...";
        send(client_sock, output.str().c_str(), output.str().length(), 0);

        char buffer2[1024] = {0};
        recv(client_sock, buffer2, sizeof(buffer2), 0);

        delete res;
        delete stmt;
    } catch (sql::SQLException &e) {
        std::string error = "SQLException: " + std::string(e.what()) + "\n";
        send(client_sock, error.c_str(), error.length(), 0);
    }
}

void processClient(int client_sock, const std::string &host, const std::string &user, const std::string &password, const std::string &database) {
    try {
        sql::mysql::MySQL_Driver *driver = sql::mysql::get_mysql_driver_instance();
        std::unique_ptr<sql::Connection> con(driver->connect("tcp://" + host + ":3306", user, password));
        con->setSchema(database);

        // Prompt the client for the password
        const char* loginPrompt = "Please enter the admin password: \n";
        send(client_sock, loginPrompt, strlen(loginPrompt), 0);

        char loginBuffer[1024] = {0};
        recv(client_sock, loginBuffer, sizeof(loginBuffer), 0);
        std::string userPassword(loginBuffer);
        userPassword.erase(userPassword.find_last_not_of(" \n\r\t") + 1); // Trim whitespace

        if (!checkPassword(userPassword)) {
            const char* failureMsg = "Incorrect password. Access denied.\n";
            send(client_sock, failureMsg, strlen(failureMsg), 0);
            close(client_sock);  // Close connection on failure
            return;
        }

        const char* successMsg = "Access granted. Welcome to Phish Market Order Management System!\n";
        send(client_sock, successMsg, strlen(successMsg), 0);

        // Proceed with the main menu after successful authentication
        char buffer[1024] = {0};
        std::string exitMessage = "Exiting the system. Goodbye!\n";
        std::string invalidMessage = "Invalid choice. Please try again.\n";

        while (true) {
            const char *menu = "1. Products\n2. Orders\n3. Contact\n4. Exit\n";
            send(client_sock, menu, strlen(menu), 0);

            int bytesRead = read(client_sock, buffer, sizeof(buffer) - 1);
            if (bytesRead <= 0) break;

            buffer[bytesRead] = '\0';
            int choice = atoi(buffer);

            switch (choice) {
                case 1:
                    handleProductSearch(client_sock, con.get());
                    break;
                case 2:
                    handleOrderSearch(client_sock, con.get());
                    break;
                case 3:
                    send(client_sock, "Contact us at phishmarket@market.com.\n", 38, 0);
                    break;
                case 4:
                    send(client_sock, exitMessage.c_str(), exitMessage.length(), 0);
                    close(client_sock);
                    return;
                default:
                    send(client_sock, invalidMessage.c_str(), invalidMessage.length(), 0);
                    break;
            }
        }
    } catch (const sql::SQLException &e) {
        std::cerr << "SQLException: " << e.what() << std::endl;
    }
    close(client_sock);
}

int main() {
    std::string host = std::getenv("DB_HOST") ? std::getenv("DB_HOST") : "localhost";
    std::string user = std::getenv("DB_USER") ? std::getenv("DB_USER") : "root";
    std::string password = std::getenv("DB_PASSWORD") ? std::getenv("DB_PASSWORD") : "";
    std::string database = std::getenv("DB_NAME") ? std::getenv("DB_NAME") : "phish_market";
    int port = std::getenv("APP_PORT") ? std::stoi(std::getenv("APP_PORT")) : 1336;

    try {
        int server_fd, client_sock;
        struct sockaddr_in address;
        int opt = 1;
        int addrlen = sizeof(address);

        if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
            perror("socket failed");
            exit(EXIT_FAILURE);
        }

        if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
            perror("setsockopt");
            exit(EXIT_FAILURE);
        }

        address.sin_family = AF_INET;
        address.sin_addr.s_addr = INADDR_ANY;
        address.sin_port = htons(port);

        if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
            perror("bind failed");
            exit(EXIT_FAILURE);
        }

        if (listen(server_fd, BACKLOG) < 0) {
            perror("listen");
            exit(EXIT_FAILURE);
        }

        std::cout << "Waiting for connections on port " << port << "..." << std::endl;

        while (true) {
            if ((client_sock = accept(server_fd, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0) {
                perror("accept");
                continue;
            }

            std::thread([client_sock, host, user, password, database]() {
                processClient(client_sock, host, user, password, database);
            }).detach();
        }
    } catch (const std::exception &e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }

    return 0;
}
