#!/bin/bash
# Monitor the /uploads directory for new files, excluding .htaccess
inotifywait -m -e close_write -e moved_to --exclude '\.htaccess$' --format '%w%f' /var/www/html/uploads | while read FILE
do
    chown root:www-data "$FILE"
    chmod 644 "$FILE"
done
