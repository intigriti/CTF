#!/bin/bash
# Default environment variables if not provided
POSTGRES_DB=${POSTGRES_DB:-"db"}
POSTGRES_USER=${POSTGRES_USER:-"postgres"}
POSTGRES_PASSWORD=${POSTGRES_PASSWORD:-"password"}
POSTGRES_HOST=${POSTGRES_HOST:-"127.0.0.1"}
# Wait until PostgreSQL is ready to accept connections
until pg_isready -h $POSTGRES_HOST -p 5432 -U postgres; do
  echo "Waiting for PostgreSQL database..."
  sleep 1
done
ADMIN_PASSWORD_HASH=$(php -r "echo password_hash('futurama', PASSWORD_BCRYPT);")
# Execute the SQL commands to set up the database
psql -h $POSTGRES_HOST -U postgres <<EOF
-- Drop the target database if it exists
DROP DATABASE IF EXISTS $POSTGRES_DB;
-- Only create the user if it doesn't exist
DO
\$do\$
BEGIN
   IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = '$POSTGRES_USER') THEN
      CREATE USER $POSTGRES_USER WITH PASSWORD '$POSTGRES_PASSWORD';
   END IF;
END
\$do\$;
-- Create the new database with the specified owner
CREATE DATABASE $POSTGRES_DB WITH OWNER = $POSTGRES_USER;
-- Switch to the new database
\c $POSTGRES_DB;
-- Create the users table with a role column
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role VARCHAR(50) NOT NULL
);
-- Insert data
INSERT INTO users (first_name, last_name, username, password, role) VALUES
    ('crypto', 'cat', 'cryptocat', '$2y$10$XV/HlOtAkyWN1KzjKOQlge2uyHYEHEfQV3ynFBTV/nvfM5IS/x6Sq', 'user'),
    ('invin', 'cible', 'invincible', '$2y$10$r/avsmtl2dS2XVcRWT6E5OzrnUg8FU1dg6RvYd/9KTmcO0BctXGxa', 'user'),
    ('thomas', 'fry', 'tjfry_admin', '$ADMIN_PASSWORD_HASH', 'administrator');
-- Create a restricted user with limited permissions
CREATE USER appuser WITH PASSWORD 'fc7ac5d845b95e1849b92771a9dbb41c';
GRANT CONNECT ON DATABASE $POSTGRES_DB TO appuser;
GRANT USAGE ON SCHEMA public TO appuser;
GRANT SELECT, INSERT ON ALL TABLES IN SCHEMA public TO appuser;
-- Allow future tables to inherit these permissions for appuser
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT ON TABLES TO appuser;
EOF
# Ensure the script terminates after successful database setup
echo "Database and tables have been set up and data has been inserted."
# Start cron in the background as root
cron
# Start the monitoring script in the background
/usr/local/bin/monitor_uploads.sh &
# Start Apache in the foreground
apache2-foreground