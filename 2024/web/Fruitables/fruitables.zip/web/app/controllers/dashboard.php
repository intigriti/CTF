<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /404.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User Dashboard</title>
    <?php include('../partials/head.php'); ?>
</head>
<body>
    <?php include('../partials/navbar.php'); ?>
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6">User Dashboard</h1>
        <ol class="breadcrumb justify-content-center mb-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="#">Pages</a></li>
            <li class="breadcrumb-item active text-white">Dashboard</li>
        </ol>
    </div>
    <div class="container-fluid py-5">
        <div class="container py-5">
            <h1 class="mb-4">Welcome to your Dashboard</h1>
            <p>Here is your special content. Enjoy your stay!</p>
            <div class="random-content mb-4">
                <p id="randomMessage"></p>
            </div>
            <form id="randomForm">
                <div class="row g-5">
                    <div class="col-md-12">
                        <div class="form-item">
                            <label class="form-label my-3">Provide your input and see what happens!<sup>*</sup></label>
                            <input type="text" name="userInput" class="form-control" placeholder="Type anything">
                        </div>
                    </div>
                </div>
                <div class="text-center align-items-center justify-content-center pt-4">
                    <button type="submit" class="btn btn-primary py-3 px-4 text-uppercase w-100">Submit</button>
                </div>
            </form>
        </div>
    </div>
    <?php include('../partials/footer.php'); ?>
    <a href="#" class="btn btn-primary border-3 border-primary rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>
    <?php include('../partials/scripts.php'); ?>
    <script>
        const randomMessages = [
            "Great choice!",
            "You are awesome!",
            "Keep up the good work!",
            "This is amazing!",
            "What a fantastic idea!"
        ];
        document.getElementById('randomForm').addEventListener('submit', function(event) {
            event.preventDefault();
            const randomMessage = randomMessages[Math.floor(Math.random() * randomMessages.length)];
            document.getElementById('randomMessage').textContent = randomMessage;
        });
    </script>
</body>
</html>
