<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /404.php');
    exit();
}
if (!isset($_COOKIE['admin-privs']) || $_COOKIE['admin-privs'] !== $_SESSION['admin-privs']) {
    header("Location: /404.php");
    exit();
}
$jokes = [
    "Why don't scientists trust atoms? Because they make up everything! 😂",
    "I'm reading a book on anti-gravity. It's impossible to put down! 🤣",
    "Why was the math book sad? It had too many problems. 😆",
    "I told my wife she was drawing her eyebrows too high. She looked surprised. 😹",
    "Why don’t skeletons fight each other? They don’t have the guts. 😁"
];
$random_joke = $jokes[array_rand($jokes)];
$upload_message = '';
if (isset($_POST["submit"])) {
    $target_dir = "../uploads/";
    $filename = $_FILES["fileToUpload"]["name"];
    
    $allowed_extensions = ['.jpg', '.jpeg', '.png'];
    $allowed_mimes = ['image/jpeg', 'image/jpg', 'image/png'];
    $file_mime = mime_content_type($_FILES["fileToUpload"]["tmp_name"]);
    
    $valid_extension = false;
    foreach ($allowed_extensions as $ext) {
        if (strpos(strtolower($filename), $ext) !== false) {
            $valid_extension = true;
            break;
        }
    }
    if (!$valid_extension || !in_array($file_mime, $allowed_mimes)) {
        $upload_message = "🚫 Only JPEG and PNG files are allowed.";
    } elseif ($_FILES["fileToUpload"]["size"] > 5000000) {
        $upload_message = "🚫 Sorry, your file is too large.";
    } else {
        $random_hash = hash('md5', uniqid(rand(), true));
        preg_match('/(\.[^.]+)+$/', $filename, $matches);
        $extension = $matches[0];
        $new_filename = $random_hash . $extension;
        $target_file = $target_dir . $new_filename;
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            $upload_message = "✅ The file " . htmlspecialchars(basename($new_filename)) . " has been uploaded.";
        } else {
            $upload_message = "🚫 Sorry, there was an error uploading your file.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Dashboard</title>
    <?php include('../partials/head.php'); ?>
</head>
<body>
    <?php include('../partials/navbar.php'); ?>
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6">Admin Dashboard</h1>
        <ol class="breadcrumb justify-content-center mb-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="#">Pages</a></li>
            <li class="breadcrumb-item active text-white">Dashboard</li>
        </ol>
    </div>
    <div class="container-fluid py-5">
        <div class="container py-5">
            <h1 class="mb-4">Welcome to your Dashboard Admin</h1>
            <p>Here is your content. Enjoy your stay!</p>
            <p><?php echo $random_joke; ?></p>
            <?php if ($upload_message): ?>
                <div class="alert alert-info">
                    <?php echo $upload_message; ?>
                </div>
            <?php endif; ?>
            <h2 class="mt-5">File Upload</h2>
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="fileUpload">Select file to upload:</label>
                    <input type="file" name="fileToUpload" id="fileUpload" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary mt-3" name="submit">Upload File</button>
            </form>
        </div>
    </div>
    <?php include('../partials/footer.php'); ?>
    <a href="#" class="btn btn-primary border-3 border-primary rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>
    <?php include('../partials/scripts.php'); ?>
</body>
</html>
