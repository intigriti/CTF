<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Account</title>
        <?php include 'partials/head.php'; ?>
    </head>
    <body>
        
        <div id="spinner" class="show w-100 vh-100 bg-white position-fixed translate-middle top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-grow text-primary" role="status"></div>
        </div>
        
        <?php include 'partials/navbar.php'; ?>
        
        <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Search by keyword</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body d-flex align-items-center">
                        <div class="input-group w-75 mx-auto d-flex">
                            <input type="search" class="form-control p-3" placeholder="keywords" aria-describedby="search-icon-1" />
                            <span id="search-icon-1" class="input-group-text p-3"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container-fluid page-header py-5">
            <h1 class="text-center text-white display-6">Account Registration</h1>
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                <li class="breadcrumb-item active text-white">Account</li>
            </ol>
        </div>
        
        <div class="container-fluid py-5">
            <div class="container py-5">
                <h1 class="mb-4">Register An Account</h1>
                <?php if (isset($_GET['error'])): ?>
                    <div class="alert alert-danger"><?= htmlspecialchars($_GET['error']); ?></div>
                <?php endif; ?>
                <form id="checkoutForm" method="POST" action="/auth/fruitables_register.php">
                    <div class="row g-5">
                        <div class="col-md-12 col-lg-6 col-xl-7">
                            <div class="row">
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">First Name<sup>*</sup></label>
                                        <input type="text" name="first_name" class="form-control" required />
                                    </div>
                                </div>
                                <div class="col-md-12 col-lg-6">
                                    <div class="form-item w-100">
                                        <label class="form-label my-3">Last Name<sup>*</sup></label>
                                        <input type="text" name="last_name" required class="form-control" />
                                    </div>
                                </div>
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Username<sup>*</sup></label>
                                <input type="text" name="username" required class="form-control" />
                            </div>
                            <div class="form-item">
                                <label class="form-label my-3">Password<sup>*</sup></label>
                                <input type="password" name="password" required class="form-control" />
                            </div>
                            <div class="text-center align-items-center justify-content-center pt-4">
                                <button type="submit" class="btn btn-primary py-3 px-4 text-uppercase w-100">Create Account</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <?php include('partials/footer.php'); ?>
        
        <a href="#" class="btn btn-primary border-3 border-primary rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>
        <?php include('partials/scripts.php'); ?>
    </body>
</html>
