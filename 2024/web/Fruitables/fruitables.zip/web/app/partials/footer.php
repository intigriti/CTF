<div class="container-fluid bg-dark text-white-50 footer pt-5 mt-5">
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-3 col-md-6">
                <h4 class="text-light mb-3">Contact</h4>
                <p>Address: 123 Street, NY 12345</p>
                <p>Email: example@example.com</p>
                <p>Phone: +012 345 6789</p>
            </div>
        </div>
    </div>
</div>
