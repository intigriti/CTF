
<div class="container-fluid fixed-top">
    <div class="container px-0">
        <nav class="navbar navbar-light bg-white navbar-expand-xl">
            <a href="/index.php" class="navbar-brand"><h1 class="text-primary display-6">Fruitables</h1></a>
            <button class="navbar-toggler py-2 px-3" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars text-primary"></span>
            </button>
            <div class="collapse navbar-collapse bg-white" id="navbarCollapse">
                <div class="navbar-nav mx-auto">
                    <a href="/index.php" class="nav-item nav-link">Home</a>
                    <a href="/shop.php" class="nav-item nav-link">Shop</a>
                    <a href="/shop-detail.php" class="nav-item nav-link">Shop Detail</a>
                    <a href="/checkout.php" class="nav-item nav-link">Checkout</a>
                    <a href="/contact.php" class="nav-item nav-link">Contact</a>
                </div>
            </div>
        </nav>
    </div>
</div>
