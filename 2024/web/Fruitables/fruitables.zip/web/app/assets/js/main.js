document.addEventListener("DOMContentLoaded", function () {
    // Handle spinner visibility
    function handleSpinner() {
        setTimeout(function () {
            var spinner = document.getElementById("spinner");
            if (spinner) {
                spinner.classList.remove("show");
            }
        }, 1);
    }
    handleSpinner(); // Handle sticky navbar shadow
    window.addEventListener("scroll", function () {
        var scrollTop = window.scrollY;
        var navbar = document.querySelector(".fixed-top");
        if (window.innerWidth < 992) {
            if (scrollTop > 55) {
                navbar.classList.add("shadow");
            } else {
                navbar.classList.remove("shadow");
            }
        } else {
            if (scrollTop > 55) {
                navbar.classList.add("shadow");
                navbar.style.top = "-55px";
            } else {
                navbar.classList.remove("shadow");
                navbar.style.top = "0";
            }
        } // Handle back-to-top button visibility
        var backToTop = document.querySelector(".back-to-top");
        if (scrollTop > 300) {
            backToTop.style.display = "block";
        } else {
            backToTop.style.display = "none";
        }
    }); // Handle back-to-top button click
    document.querySelector(".back-to-top").addEventListener("click", function () {
        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    });
    if (window.OwlCarousel) {
        $(".testimonial-carousel").owlCarousel({
            autoplay: true,
            smartSpeed: 2000,
            center: false,
            dots: true,
            loop: true,
            margin: 25,
            nav: true,
            navText: ['<i class="bi bi-arrow-left"></i>', '<i class="bi bi-arrow-right"></i>'],
            responsiveClass: true,
            responsive: {
                0: { items: 1 },
                576: { items: 1 },
                768: { items: 1 },
                992: { items: 2 },
                1200: { items: 2 },
            },
        });
        $(".vegetable-carousel").owlCarousel({
            autoplay: true,
            smartSpeed: 1500,
            center: false,
            dots: true,
            loop: true,
            margin: 25,
            nav: true,
            navText: ['<i class="bi bi-arrow-left"></i>', '<i class="bi bi-arrow-right"></i>'],
            responsiveClass: true,
            responsive: {
                0: { items: 1 },
                576: { items: 1 },
                768: { items: 2 },
                992: { items: 3 },
                1200: { items: 4 },
            },
        });
    } // Handle video modal
    var videoSrc;
    document.querySelectorAll(".btn-play").forEach(function (button) {
        button.addEventListener("click", function () {
            videoSrc = this.getAttribute("data-src");
        });
    });
    var videoModal = document.getElementById("videoModal");
    if (videoModal) {
        videoModal.addEventListener("shown.bs.modal", function () {
            document.getElementById("video").src = videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0";
        });
        videoModal.addEventListener("hide.bs.modal", function () {
            document.getElementById("video").src = videoSrc;
        });
    } // Handle quantity button clicks
    document.querySelectorAll(".quantity button").forEach(function (button) {
        button.addEventListener("click", function () {
            var input = button.closest(".quantity").querySelector("input");
            var oldValue = parseFloat(input.value);
            var newVal = button.classList.contains("btn-plus") ? oldValue + 1 : Math.max(0, oldValue - 1);
            input.value = newVal;
        });
    }); // Reset checkout form if needed
    var checkoutForm = document.getElementById("checkoutForm");
    if (checkoutForm) {
        checkoutForm.reset();
    }
});
