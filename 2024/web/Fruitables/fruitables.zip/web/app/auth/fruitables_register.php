<?php
include('../controllers/db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header("Location: fruitables_login.php?error=" . urlencode("Sorry, registration is currently closed!"));
    exit();
}
?>
