<?php
session_start();
include('../controllers/db.php');

$error_message = isset($_GET['error']) ? $_GET['error'] : "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = trim($_POST['password']);
    $query = "SELECT * FROM users WHERE username = '$username'"; 
    $stmt = $conn->query($query);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        if ($user['role'] === 'administrator') {
            $admin_privs_hash = hash('sha256', 'admin' . session_id());
            $_SESSION['admin-privs'] = $admin_privs_hash;
            setcookie('admin-privs', $admin_privs_hash, time() + 3600, '/', '', false, true);
            header('Location: /controllers/admin_dashboard.php');
        } else {
            header('Location: /controllers/dashboard.php');
        }
        exit;
    } else {
        $error_message = "🚫 Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <?php include('../partials/head.php'); ?>
</head>
<body>
    <?php include('../partials/navbar.php'); ?>
    <div class="container-fluid page-header py-5">
        <h1 class="text-center text-white display-6">Account Login</h1>
        <ol class="breadcrumb justify-content-center mb-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="#">Pages</a></li>
            <li class="breadcrumb-item active text-white">Login</li>
        </ol>
    </div>
    
    <div class="container-fluid py-5">
        <div class="container py-5">
            <h1 class="mb-4">Login to your Account</h1>
            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>
            <form id="checkoutForm" method="POST">
                <div class="row g-5">
                    <div class="col-md-12 col-lg-6 col-xl-7">
                        <div class="form-item">
                            <label class="form-label my-3">Username<sup>*</sup></label>
                            <input type="text" name="username" required class="form-control" />
                        </div>
                        <div class="form-item">
                            <label class="form-label my-3">Password<sup>*</sup></label>
                            <input type="password" name="password" required class="form-control" />
                        </div>
                        <button type="submit" class="btn btn-primary py-3 px-4 text-uppercase w-100 mt-4">Login</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php include('../partials/footer.php'); ?>
    <?php include('../partials/scripts.php'); ?>
</body>
</html>
