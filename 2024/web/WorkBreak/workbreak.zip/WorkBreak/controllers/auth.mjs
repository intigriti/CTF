import express from "express";
import rateLimit from "express-rate-limit";
import { check, cookie } from "express-validator";
import { validateRequestData } from "../utils/middlewares.mjs";
import AuthService from "../services/auth.mjs";
import Errors from "../misc/errors.mjs";
import Constants from "../misc/constants.mjs";

const auth = express.Router();

const AuthLimiter = rateLimit({
    windowMs: 10 * 1000, // 10 seconds
    max: 5,
    message: Errors.TOO_MANY_REQUESTS,
});

auth.post(
    "/login",
    AuthLimiter,
    [
        // Email validation
        check("email").isEmail().withMessage(Errors.INVALID_EMAIL).normalizeEmail(),
        // Password validation
        check("password")
            .matches(Constants.REGEX_STRONG_PASSWORD)
            .withMessage(Errors.INVALID_PASSWORD),
    ],
    validateRequestData(),
    AuthService.login
);

auth.post(
    "/signup",
    AuthLimiter,
    [
        // Email validation
        check("email").isEmail().withMessage(Errors.INVALID_EMAIL).normalizeEmail(),
        // Password validation
        check("password")
            .matches(Constants.REGEX_STRONG_PASSWORD)
            .withMessage(Errors.WEAK_PASSWORD),
    ],
    validateRequestData(),
    AuthService.signup
);

auth.post(
    "/logout",
    [
        // Session validation
        cookie("SID").isUUID(4).withMessage(Errors.INVALID_UUID4),
    ],
    validateRequestData("/"),
    AuthService.logout
);

export default auth;
