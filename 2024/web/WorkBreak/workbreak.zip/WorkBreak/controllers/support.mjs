import express from "express";
import rateLimit from "express-rate-limit";
import Errors from "../misc/errors.mjs";
import { authProtection } from "../utils/middlewares.mjs";
import SupportService from "../services/support.mjs";

const support = express.Router();

const supportLimiter = rateLimit({
    windowMs: 10 * 1000, // 10 seconds
    max: 1,
    message: Errors.TOO_MANY_REQUESTS,
});

support.post("/chat", supportLimiter, authProtection(), SupportService.sendURL);

export default support;
