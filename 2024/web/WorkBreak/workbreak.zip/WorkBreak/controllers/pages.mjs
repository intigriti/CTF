import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { authProtection } from "../utils/middlewares.mjs";

const pages = express.Router();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
pages.use(express.static(path.join(__dirname, "../views/public")));

pages.get("/login", async (req, res) => {
    return res.sendFile(path.join(__dirname, "../views", "login.html"));
});

pages.get("/profile/:uuid", authProtection("/login"), async (req, res) => {
    return res.sendFile(path.join(__dirname, "../views", "profile.html"));
});

pages.get("*", authProtection("/login"), async (req, res) => {
    const user = req.user;
    return res.redirect(`/profile/${user.id}`);
});

export default pages;
