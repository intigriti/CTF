import express from "express";
import { check } from "express-validator";
import { antiAdminTampering, authProtection, validateRequestData } from "../utils/middlewares.mjs";
import UserService from "../services/user.mjs";
import Constants from "../misc/constants.mjs";
import Errors from "../misc/errors.mjs";

const user = express.Router();

user.get(
    "/profile/:uuid",
    [
        // Profile id validation
        check("uuid").isUUID(4).withMessage(Errors.INVALID_UUID4),
    ],
    validateRequestData(),
    authProtection(),
    UserService.profile
);
user.post(
    "/settings",
    [
        // Disallow tasks modification
        check("tasks").not().exists().withMessage(Errors.TASKS_NOT_ALLOWED),

        // Name validation
        check("name").custom(
            (value) =>
                value === "" ||
                Constants.REGEX_NAME.test(value) ||
                Promise.reject(Errors.INVALID_NAME)
        ),

        // Phone number validation
        check("phone").custom(
            (value) =>
                value === "" ||
                (value && Constants.REGEX_PHONE.test(value)) ||
                Promise.reject(Errors.INVALID_PHONE)
        ),

        // Position name validation
        check("position").custom(
            (value) =>
                value === "" ||
                (value && value.length >= 2) ||
                Promise.reject(Errors.INVALID_POSITION)
        ),
    ],
    antiAdminTampering,
    validateRequestData(),
    authProtection(),
    UserService.settings
);

export default user;
