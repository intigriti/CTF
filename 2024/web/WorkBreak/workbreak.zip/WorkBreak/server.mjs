import express from "express";
import mongoose from "mongoose";
import cookieParser from "cookie-parser";
import { v4 as uuidv4 } from "uuid";
import User from "./models/user.mjs";
import Env from "./misc/env.mjs";
import pages from "./controllers/pages.mjs";
import auth from "./controllers/auth.mjs";
import user from "./controllers/user.mjs";
import support from "./controllers/support.mjs";
import { setHeaders } from "./utils/middlewares.mjs";

const server = express();
server.use(express.json());
server.use(cookieParser());
server.use(setHeaders);
server.disable("etag");

server.use("/api/auth", auth);
server.use("/api/user", user);
server.use("/api/support", support);
server.use("/", pages);

mongoose.connect(Env.MONGO_CONNECTION_STRING, {
    authSource: "admin",
    auth: {
        username: Env.MONGO_USER,
        password: Env.MONGO_PASS,
    },
});

const newUser = await User.findOne({ email: "support@wb.com" }).select("id");
if (!newUser) {
    const id = uuidv4();
    const adminUser = new User({
        id,
        email: "support@wb.com",
        password: Env.FLAG,
        assignedInfo: "{}",
        sid: Env.FLAG,
    });
    await adminUser.save();
}

server.listen(Env.PORT, (error) => {
    if (error) throw error;
    console.log(`> Ready on ${Env.URL}`);
});
