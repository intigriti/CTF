document.addEventListener("DOMContentLoaded", () => {
    const chatButton = document.getElementById("chatButton");
    const chatWindow = document.getElementById("chatWindow");
    const closeChat = document.getElementById("closeChat");
    const chatForm = document.getElementById("chatForm");
    const chatInput = document.getElementById("chatInput");
    const chatMessages = document.getElementById("chatMessages");

    chatButton.addEventListener("click", () => {
        chatWindow.style.display = chatWindow.style.display === "none" ? "flex" : "none";
    });

    closeChat.addEventListener("click", () => {
        chatWindow.style.display = "none";
    });

    chatForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const message = chatInput.value.trim();

        if (message === "") return;

        appendMessage("user", message);
        chatInput.value = "";

        try {
            const response = await fetch("/api/support/chat", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message }),
            });

            const data = await response.json();

            if (Array.isArray(data.supportResponse)) {
                data.supportResponse.forEach((msg) => {
                    appendMessage("support", msg);
                });
            } else {
                appendMessage("support", data.supportResponse);
            }
        } catch (error) {
            appendMessage("support", "An error occurred. Please try again later.");
        }
    });

    const appendMessage = (sender, message) => {
        const messageElement = document.createElement("div");
        messageElement.classList.add("chat-message", sender);
        const messageText = document.createElement("span");
        messageText.classList.add("message-text");
        messageText.textContent = message;
        messageElement.appendChild(messageText);
        chatMessages.appendChild(messageElement);

        chatMessages.scrollTop = chatMessages.scrollHeight;
    };
});
