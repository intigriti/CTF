const getUserIdFromUrl = () => {
    const path = window.location.pathname;
    const segments = path.split("/");
    return segments[segments.length - 1];
};

const setError = (error) => {
    const errorText = document.getElementById("errorText");
    errorText.innerText = error;

    errorText.addEventListener("transitionend", () => {
        errorText.innerText = "";
        errorText.classList.remove("fade-out");
    });
    errorText.classList.add("fade-out");
};

let userTasks = [];
document.addEventListener("DOMContentLoaded", async function () {
    const logoutButton = document.getElementById("logoutButton");
    const performanceIframe = document.getElementById("performanceIframe");
    const profileForm = document.getElementById("profileForm");
    const editButton = document.getElementById("editButton");
    const submitButton = document.getElementById("submitButton");
    const emailField = document.getElementById("email");
    const nameField = document.getElementById("name");
    const phoneField = document.getElementById("phone");
    const positionField = document.getElementById("position");
    const userId = getUserIdFromUrl();

    try {
        const response = await fetch(`/api/user/profile/${userId}`);
        const profileData = await response.json();
        if (response.ok) {
            const userSettings = Object.assign(
                { name: "", phone: "", position: "" },
                profileData.assignedInfo
            );

            if (!profileData.ownProfile) {
                editButton.style.display = "none";
            } else {
                editButton.style.display = "inline-block";
            }

            emailField.value = profileData.email;
            nameField.value = userSettings.name;
            phoneField.value = userSettings.phone;
            positionField.value = userSettings.position;

            userTasks = userSettings.tasks || [];
            performanceIframe.addEventListener("load", () => {
                performanceIframe.contentWindow.postMessage(userTasks, "*");
            });
        } else if (response.unauthorized) {
            window.location.href = "/login";
        } else {
            setError(profileData.error);
        }
    } catch (error) {
        console.log("Error fetching profile: " + error.message);
    }

    editButton.addEventListener("click", () => {
        nameField.disabled = false;
        phoneField.disabled = false;
        positionField.disabled = false;

        nameField.classList.add("editable");
        phoneField.classList.add("editable");
        positionField.classList.add("editable");

        submitButton.style.display = "inline-block";
        editButton.style.display = "none";
    });

    profileForm.addEventListener("submit", async (e) => {
        e.preventDefault();

        const updatedSettings = {
            name: nameField.value,
            phone: phoneField.value,
            position: positionField.value,
        };

        try {
            const response = await fetch("/api/user/settings", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(updatedSettings),
            });

            if (response.ok) {
                alert("Profile updated successfully!");
                nameField.disabled = true;
                phoneField.disabled = true;
                positionField.disabled = true;

                nameField.classList.remove("editable");
                phoneField.classList.remove("editable");
                positionField.classList.remove("editable");

                submitButton.style.display = "none";
                editButton.style.display = "inline-block";
            } else if (response.unauthorized) {
                window.location.href = "/login";
            } else {
                const errorData = await response.json();
                setError(errorData.error);
            }
        } catch (error) {
            setError(error.message);
        }
    });

    logoutButton.addEventListener("click", async function () {
        try {
            const response = await fetch("/api/auth/logout", {
                method: "POST",
            });

            if (response.ok) {
                window.location.href = "/login";
            } else {
                const errorData = await response.json();
                console.log("Logout failed: " + errorData.message);
            }
        } catch (error) {
            console.log("Error during logout: " + error.message);
        }
    });
});

window.onresize = () => performanceIframe.contentWindow.postMessage(userTasks, "*");

// Not fully implemented - total tasks
window.addEventListener(
    "message",
    (event) => {
        if (event.source !== frames[0]) return;

        document.getElementById(
            "totalTasks"
        ).innerHTML = `<p>Total tasks completed: ${event.data.totalTasks}</p>`;
    },
    false
);
