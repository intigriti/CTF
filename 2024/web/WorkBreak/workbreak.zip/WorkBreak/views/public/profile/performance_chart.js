const renderPerformanceChart = (taskData) => {
    const cellMinSize = 40;
    const margin = { top: 20, right: 10, bottom: 20, left: 50 };
    const containerWidth = document.querySelector(".performance-section").clientWidth - 32;
    const cellSize = Math.min((containerWidth - margin.left - margin.right) / 52, cellMinSize);
    const containerHeight = cellSize * 7 + 84;
    const daysOfWeek = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    const monthsOfYear = [
        "Jan",
        "Feb",
        "Mar",
        "Apr",
        "May",
        "Jun",
        "Jul",
        "Aug",
        "Sep",
        "Oct",
        "Nov",
        "Dec",
    ];

    d3.select("#performanceChart svg").remove();
    const svg = d3
        .select("#performanceChart")
        .append("svg")
        .attr("width", containerWidth)
        .attr("height", containerHeight)
        .append("g")
        .attr("transform", `translate(${margin.left}, ${margin.top})`);

    const taskCounts = generateTaskHeatmapData(taskData);
    const today = new Date().toISOString().split("T")[0];
    const todayTask = taskData.find((task) => task.date === today);

    const todayTasksDiv = d3.select("#todayTasks");
    if (todayTask) {
        todayTasksDiv.html(`Tasks Completed Today: ${todayTask.tasksCompleted}`);
    } else {
        todayTasksDiv.html("Tasks Completed Today: 0");
    }

    const colorScale = d3
        .scaleLinear()
        .domain([0, d3.max(taskCounts, (d) => d.count)])
        .range(["#e0f7fa", "#004d40"]);

    const tooltip = d3
        .select("body")
        .append("div")
        .attr("class", "tooltip")
        .style("position", "absolute")
        .style("background", "white")
        .style("border", "1px solid #ccc")
        .style("padding", "10px")
        .style("border-radius", "5px")
        .style("box-shadow", "0 4px 8px rgba(0, 0, 0, 0.1)")
        .style("opacity", 0)
        .style("pointer-events", "none");

    svg.selectAll("rect")
        .data(taskCounts)
        .enter()
        .append("rect")
        .attr("x", (d) => d.week * cellSize)
        .attr("y", (d) => d.day * cellSize)
        .attr("width", cellSize - 2)
        .attr("height", cellSize - 2)
        .attr("fill", (d) => (d.count > 0 ? colorScale(d.count) : "#f0f0f0"))
        .on("mouseover", function (event, d) {
            tooltip
                .html(`Tasks Completed: ${d.count}`)
                .style("left", event.pageX + 10 + "px")
                .style("top", event.pageY - 20 + "px")
                .style("opacity", 1);
        })
        .on("mouseout", function () {
            tooltip.style("opacity", 0);
        });

    svg.selectAll(".day-label")
        .data(daysOfWeek)
        .enter()
        .append("text")
        .attr("class", "day-label")
        .attr("x", -10)
        .attr("y", (d, i) => i * cellSize + cellSize / 2)
        .style("text-anchor", "end")
        .attr("alignment-baseline", "middle")
        .text((d) => d);

    svg.selectAll(".month-label")
        .data(monthsOfYear)
        .enter()
        .append("text")
        .attr("class", "month-label")
        .attr("x", (d, i) => i * (cellSize * 4) + cellSize * 4)
        .attr("y", containerHeight - margin.bottom - 10)
        .style("text-anchor", "middle")
        .text((d) => d);
};

const generateTaskHeatmapData = (taskData) => {
    const data = [];
    const startDate = new Date("2024-01-01");
    const taskMap = new Map(taskData.map((task) => [task.date, task.tasksCompleted]));

    for (let week = 0; week < 52; week++) {
        for (let day = 0; day < 7; day++) {
            const currentDate = new Date(startDate);
            currentDate.setDate(currentDate.getDate() + week * 7 + day);

            const formattedDate = currentDate.toISOString().split("T")[0];
            const taskCount = taskMap.get(formattedDate) || 0;

            data.push({
                week: week,
                day: day,
                count: taskCount,
            });
        }
    }
    return data;
};

window.addEventListener(
    "message",
    (event) => {
        if (event.source !== window.parent) return;
        renderPerformanceChart(event.data);
    },
    false
);
