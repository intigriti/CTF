function setError(error) {
    const errorText = document.getElementById("errorText");
    errorText.innerText = error;

    errorText.addEventListener("transitionend", () => {
        errorText.innerText = "";
        errorText.classList.remove("fade-out");
    });
    errorText.classList.add("fade-out");
}

let authMethod = "login";
document.addEventListener("DOMContentLoaded", () => {
    const switchFormButton = document.getElementById("switchFormButton");
    const authForm = document.getElementById("authForm");
    const formTitle = document.getElementById("formTitle");
    const password = document.getElementById("authPassword");
    const submitButton = document.getElementById("authSubmit");
    const switchButton = document.getElementById("switchFormButton");

    switchFormButton.addEventListener("click", () => {
        if (authMethod === "login") {
            authMethod = "signup";
            formTitle.innerText = "Signup";
            submitButton.innerText = "Signup";
            switchButton.innerText = "Switch to Login";
        } else {
            authMethod = "login";
            formTitle.innerText = "Login";
            submitButton.innerText = "Login";
            switchButton.innerText = "Switch to Signup";
        }

        password.value = "";
    });

    authForm.addEventListener("submit", async (e) => {
        const password = document.getElementById("authPassword").value;
        const email = document.getElementById("authEmail").value;
        e.preventDefault();
        try {
            const response = await fetch(`/api/auth/${authMethod}`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ email, password }),
            });

            if (!response.ok) {
                const errorData = await response.json();
                setError(errorData.error);
            } else {
                if (authMethod === "signup") {
                    alert("Signup successful!");
                } else if (response.redirected) {
                    window.location.href = "/";
                }
            }
        } catch (error) {
            setError(error.message);
        }
    });
});
