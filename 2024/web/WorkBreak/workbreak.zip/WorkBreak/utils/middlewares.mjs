import { validationResult } from "express-validator";
import User from "../models/user.mjs";
import HTTPStatusCodes from "../misc/httpStatusCodes.mjs";
import Env from "../misc/env.mjs";
import Errors from "../misc/errors.mjs";

const authProtection = (redirectPage) => async (req, res, next) => {
    try {
        const { SID: sid } = req.cookies;
        const user = await User.findOne({ sid: sid ?? "" });

        if (!user) {
            if (redirectPage) return res.redirect(redirectPage);
            return res.status(HTTPStatusCodes.UNAUTHORIZED).json({ error: Errors.UNAUTHORIZED });
        }
        req.user = user;
        return next();
    } catch (error) {
        console.log(error);
        return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
    }
};

const antiAdminTampering = (req, res, next) => {
    try {
        const { SID: sid } = req.cookies;

        if (sid === Env.FLAG) {
            return res
                .status(HTTPStatusCodes.UNAUTHORIZED)
                .json({ error: Errors.USER_MODIFICATION_FORBIDDEN });
        }
        return next();
    } catch (error) {
        console.log(error);
        return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
    }
};

const validateRequestData = (redirectPage) => async (req, res, next) => {
    // Validate request data
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        if (redirectPage) return res.redirect(redirectPage);
        return res.status(HTTPStatusCodes.BAD_REQUEST).json({ error: errors.array()[0].msg });
    }
    return next();
};

const setHeaders = async (req, res, next) => {
    res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
    res.set("Surrogate-Control", "no-store");
    res.set("X-Frame-Options", "SAMEORIGIN");
    next();
};

export { authProtection, antiAdminTampering, validateRequestData, setHeaders };
