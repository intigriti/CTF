import dotenv from "dotenv";

dotenv.config();

export default class Env {
    static ENV = process.env.ENV ?? "dev";

    static URL = `http://${process.env.SERVER_HOST}:${process.env.SERVER_PORT}`;

    static FRONTEND_DOMAIN = process.env.FRONTEND_DOMAIN ?? "";

    static PORT = parseInt(process.env.SERVER_PORT ?? "80");

    static MONGO_USER = process.env.MONGO_USER ?? "";

    static MONGO_PASS = process.env.MONGO_PASS ?? "";

    static MONGO_CONNECTION_STRING = `mongodb://${process.env.MONGO_HOST}:${
        process.env.MONGO_PORT ?? "27017"
    }/challenge`;

    static SECURE_COOKIE = Env.ENV === "prod";

    static FLAG = process.env.FLAG ?? "";
}
