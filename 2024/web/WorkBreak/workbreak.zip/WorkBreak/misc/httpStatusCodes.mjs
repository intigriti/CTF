export default class HTTPStatusCodes {
  static OK = 200;

  static CREATED = 201;

  static SEE_OTHER = 303;

  static BAD_REQUEST = 400;

  static UNAUTHORIZED = 401;

  static FORBIDDEN = 403;

  static NOT_FOUND = 404;

  static CONFLICT = 409;

  static IM_A_TEAPOT = 418;

  static TOO_MANY_REQUESTS = 429;

  static SERVER_ERROR = 500;
}
