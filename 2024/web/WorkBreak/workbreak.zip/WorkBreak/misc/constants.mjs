export default class Constants {
  static SESSION_EXPIRATION = 6 * 3600 * 1000;

  static REGEX_STRONG_PASSWORD =
    /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d !@#$%^&*+=\-_.,;:<>?~(){}[\]|]{8,}$/;

  static REGEX_NAME = /^[A-Za-z]{2,}(?:[ '-][A-Za-z]+)*$/;

  static REGEX_PHONE =
    /^(?:\+?(\d{1,3}))?[-. (]*(\d{3})[-. )]*(\d{3})[-. ]*(\d{4})(?: *x(\d+))?$/;
}
