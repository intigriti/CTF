export default class Errors {
    static BAD_REQUEST = "Bad Request";

    static UNAUTHORIZED = "Unauthorized";

    static FORBIDDEN = "FORBIDDEN";

    static TOO_MANY_REQUESTS = "[Rate limit] Too Many Requests, Please Try Again After 10 Seconds";

    static SERVER_ERROR = "Server Error";

    static USER_ALREADY_EXISTS = "User Already Exists";

    static NOT_ARRAY_PAYLOAD = "Payload Should Be an Array";

    static INVALID_EMAIL = "Invalid Email";

    static INVALID_NAME = "Invalid Name";

    static INVALID_PHONE = "Invalid Phone Number";

    static INVALID_POSITION = "Position Must Be at Least 2 Characters Long";

    static USER_MODIFICATION_FORBIDDEN = "Not allowed to modify this user";

    static TASKS_NOT_ALLOWED = "Not Allowed to Modify Tasks";

    static INVALID_PASSWORD = "Invalid Password";

    static WEAK_PASSWORD =
        "Password Must Contain at Least One Letter, One Digit, and Be at Least 8 Characters Long";

    static INVALID_UUID4 = "Invalid UUID4";
}
