import User from "../models/user.mjs";
import HTTPStatusCodes from "../misc/httpStatusCodes.mjs";
import Errors from "../misc/errors.mjs";

export default class UserService {
    static async profile(req, res) {
        try {
            const { user } = req;
            const profileId = req.params.uuid;
            const profileUser = await User.findOne({ id: profileId });

            const response = {
                email: profileUser?.email || "",
                assignedInfo: profileUser ? JSON.parse(profileUser.assignedInfo) : {},
                ownProfile: profileId === user.id,
            };

            return res.status(HTTPStatusCodes.OK).json(response);
        } catch (error) {
            console.error(error);
            return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
        }
    }

    static async settings(req, res) {
        try {
            const user = req.user;
            const settings = req.body;

            const currentInfo = user.assignedInfo ? JSON.parse(user.assignedInfo) : {};
            const safeSettings = JSON.parse(JSON.stringify(settings));
            const updatedInfo = { ...currentInfo, ...safeSettings };
            user.assignedInfo = JSON.stringify(updatedInfo);
            await user.save();

            return res.status(HTTPStatusCodes.OK).json({ status: "Settings updated successfully" });
        } catch (error) {
            console.log(error);
            return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
        }
    }
}
