import crypto from "crypto";
import { v4 as uuidv4 } from "uuid";
import Constants from "../misc/constants.mjs";
import Env from "../misc/env.mjs";
import Errors from "../misc/errors.mjs";
import HTTPStatusCodes from "../misc/httpStatusCodes.mjs";
import User from "../models/user.mjs";

export default class AuthService {
    /**
     *	█▀▀ █▀█ █▀█ █▀▀   █▀▄▀█ █▀▀ ▀█▀ █ █ █▀█ █▀▄ █▀
     *	█▄▄ █▄█ █▀▄ ██▄   █ ▀ █ ██▄  █  █▀█ █▄█ █▄▀ ▄█
     */

    static async login(req, res) {
        const { email, password } = req.body;

        try {
            // Check if the user exists
            const currentUser = await User.findOne({ email }).select("id password");
            if (
                !currentUser ||
                currentUser.password !== AuthService.hashPassword(password, currentUser.id)
            ) {
                return res
                    .status(HTTPStatusCodes.UNAUTHORIZED)
                    .json({ error: Errors.UNAUTHORIZED });
            }

            // Assigns a session
            const sid = uuidv4();
            await User.updateOne({ email }, { sid });

            // Set SID and redirect
            AuthService.setSecureCookie(res, sid);
            return res.redirect("/");
        } catch (error) {
            console.log(error);
            return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
        }
    }

    static async signup(req, res) {
        const { email, password } = req.body;

        try {
            // Check if the new user already exists
            const newUser = await User.findOne({ email }).select("id");
            if (!newUser) {
                const id = uuidv4();
                const user = new User({
                    id,
                    email,
                    password: AuthService.hashPassword(password, id),
                    assignedInfo: `{"name": "Anon"}`,
                });
                await user.save();
            } else {
                return res
                    .status(HTTPStatusCodes.CONFLICT)
                    .json({ error: Errors.USER_ALREADY_EXISTS });
            }
            return res.status(HTTPStatusCodes.CREATED).send();
        } catch (error) {
            console.log(error);
            return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
        }
    }

    static async logout(req, res) {
        const { SID: sid } = req.cookies;

        try {
            // Delete SID server-side and client-side
            await User.updateOne({ sid }, { sid: uuidv4() });
            AuthService.setSecureCookie(res, "", "SID", 0);
            return res.redirect("/");
        } catch (error) {
            console.log(error);
            if (error.name === "DocumentNotFoundError") {
                AuthService.setSecureCookie(res, "", "SID", 0);
                return res.redirect("/");
            }
            return res.status(HTTPStatusCodes.SERVER_ERROR).json({ error: Errors.SERVER_ERROR });
        }
    }

    /**
     *	█ █ █▀▀ █   █▀█ █▀▀ █▀█   █▀▄▀█ █▀▀ ▀█▀ █ █ █▀█ █▀▄ █▀
     *	█▀█ ██▄ █▄▄ █▀▀ ██▄ █▀▄   █ ▀ █ ██▄  █  █▀█ █▄█ █▄▀ ▄█
     */

    static setSecureCookie(response, value, key = "SID", expires = Constants.SESSION_EXPIRATION) {
        let cookieExpiration = Date.now() + expires;
        if (expires === 0) {
            cookieExpiration = 0;
        }

        response.cookie(key, value, {
            expires: new Date(cookieExpiration),
            path: "/",
            secure: Env.SECURE_COOKIE,
            sameSite: "lax",
        });
    }

    static hashPassword(password, salt) {
        const hash = crypto.createHash("sha512");
        hash.update(`${salt}${password}`);
        return hash.digest("hex");
    }
}
