import Env from "../misc/env.mjs";
import { URL } from "url";
import puppeteer from "puppeteer";
import HTTPStatusCodes from "../misc/httpStatusCodes.mjs";

export default class SupportService {
    static async sendURL(req, res) {
        const supportResponse = [];
        let browser;
        try {
            const { message } = req.body;

            supportResponse.push(
                "Hi, I'm a Support Engineer. I will document my steps as I attempt to replicate the issue."
            );

            if (!new RegExp(Env.FRONTEND_DOMAIN).test(new URL(message).host)) {
                supportResponse.push(
                    "Not too sure what this host is, so I won't click on it to avoid security risks."
                );
                supportResponse.push(`Please provide a URL containing the challenge domain.`);
                return res.status(HTTPStatusCodes.OK).json({ supportResponse });
            }

            console.log("Launching puppeteer");
            browser = await puppeteer.launch({
                timeout: 0,
                protocolTimeout: 30000,
                defaultViewport: null,
                args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"],
            });

            let page = await browser.newPage();

            supportResponse.push("Logging into my staff account.");

            await page.setCookie({
                name: "SID",
                value: Env.FLAG,
                domain: new URL(message).host,
            });
            try {
                await page.goto(message, { waitUntil: "networkidle0" });
                await page.setViewport({
                    width: 1280,
                    height: 800,
                });
                await new Promise((resolve) => setTimeout(resolve, 2000));
            } catch (error) {
                supportResponse.push(
                    "There was an issue navigating to the page. It might be down or slow to respond."
                );
                console.log("Navigation failed: ", error);
                await browser.close();
                return res.status(500).json({ supportResponse });
            }

            supportResponse.push("I clicked on the link. Not sure what the problem is.");
            await page.close();
            await browser.close();
        } catch (error) {
            console.log("Caught an error: ", error);

            if (error instanceof TypeError) {
                supportResponse.push(
                    "I’m a bit busy at the moment. Can you just send me your profile URL, and I'll check what the problem is?"
                );
            }
            try {
                await browser.close();
            } catch (error) {
                console.log(error);
            }

            return res.status(HTTPStatusCodes.OK).json({ supportResponse });
        }
        return res.status(HTTPStatusCodes.OK).json({ supportResponse });
    }
}
