<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $validUsername = 'agent_1337';
    $validPasswordHash = '91a915b6bdcfb47045859288a9e2bd651af246f07a083f11958550056bed8eac';

    $passwordHash = hash('sha256', $password);

    if ($username === $validUsername && $passwordHash === $validPasswordHash) {
        header('Location: topsecret_a9aedc6c39f654e55275ad8e65e316b3.php');
        exit();
    } else {
        header('Location: secret_172346606e1d24062e891d537e917a90.html?error=Invalid+credentials!');
        exit();
    }
}
?>
